/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.quanlybansach.ui;

import java.awt.Color;
import java.sql.SQLException;

import javax.swing.JFrame;

import com.mycompany.quanlybansach.connectDB.ShareData;
import com.mycompany.quanlybansach.dao.NhanVienDao;
import com.mycompany.quanlybansach.entity.NhanVien;
import com.mycompany.quanlybansach.raven.menu.MenuEvent;
import javax.swing.JOptionPane;

/**
 *
 * @author quang
 */
public class GiaoDienChinh extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;

    /**
     * Creates new form GiaoDien
     */
    public GiaoDienChinh() {
        initComponents();

        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setBackground(new Color(99, 183, 183));

        DangNhapUI dialog = new DangNhapUI(this, true);
        dialog.setVisible(true);
        
        processLoginSuccessful();
        showNhanVien();

        pnlBody.removeAll();
        pnlBody.add(new TrangChu());
        pnlBody.revalidate();
        pnlBody.repaint();
        menu1.setEvent(new MenuEvent() {

            @Override
            public void selected(int index, int subIndex) throws SQLException {

                if (index == 1 && subIndex == 1) {
                    pnlBody.removeAll();
                    pnlBody.add(new TrangChu());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }

                if (index == 1 && subIndex == 3) { 
                    DangNhapUI loginui = new DangNhapUI(GiaoDienChinh.this, true);
                    loginui.setVisible(true);  
                }

                if (index == 2 && subIndex == 1) {
                    pnlBody.removeAll();
                    pnlBody.add(new QuanLyKhachHang());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 2 && subIndex == 2) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyNV());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 3) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyHoaDon());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }
                }
                if (index == 2 && subIndex == 4) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyDatSach());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 5) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLySach());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 6) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyDungCuHocTap());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 7) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyNhaCungCap());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 8) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyNXB());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 9) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyTacGia());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 2 && subIndex == 10) {
                    NhanVienDao dao = new NhanVienDao();
                    NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
                    if (nv != null) {
                        if (nv.getChucVu() == 0) {
                            pnlBody.removeAll();
                            pnlBody.add(new QuanLyTheLoai());
                            pnlBody.revalidate();
                            pnlBody.repaint();
                        } else {
                            JOptionPane.showMessageDialog(null, "Bạn phải là quản lý mới được sử dụng chức năng này");
                        }
                    }

                }
                if (index == 3 && subIndex == 1) {
                    pnlBody.removeAll();
                    String maNV = lblMaNV.getText();
                    NhanVien nv = new NhanVien();
                    nv.setMaNV(maNV);
                    pnlBody.add(new DatSachUI(nv));
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 3 && subIndex == 2) {
                    pnlBody.removeAll();
                    String maNV = lblMaNV.getText();
                    NhanVien nv = new NhanVien();
                    nv.setMaNV(maNV);
                    pnlBody.add(new TaoHoaDon(nv));
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 4 && subIndex == 1) {
                    pnlBody.removeAll();
                    pnlBody.add(new TKSach());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 4 && subIndex == 2) {
                    pnlBody.removeAll();
                    pnlBody.add(new TKDungCuHocTap());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 4 && subIndex == 3) {
                    pnlBody.removeAll();
                    pnlBody.add(new TKKhachHang());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 4 && subIndex == 4) {
                    pnlBody.removeAll();
                    pnlBody.add(new TKNhanVien());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }

                if (index == 5 && subIndex == 1) {
                    pnlBody.removeAll();
                    pnlBody.add(new ThongKeDoanhThu());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 5 && subIndex == 2) {
                    pnlBody.removeAll();
                    pnlBody.add(new ThongKeKhachHang());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }
                if (index == 5 && subIndex == 3) {
                    pnlBody.removeAll();
                    pnlBody.add(new ThongKeSanPham());
                    pnlBody.revalidate();
                    pnlBody.repaint();

                }

            }
        });
    }

    private void showNhanVien() {
        try {
            NhanVienDao dao = new NhanVienDao();
            NhanVien nv = dao.TimKiemNVIsMaNV(lblMaNV.getText());
            if (nv != null) {
                lblTenNV.setText(nv.getTenNV());
                lblSĐT.setText(nv.getsDT());
                if (nv.getChucVu() == 0) {
                    lblChucVu.setText("Quản lý");
                } else {
                    lblChucVu.setText("Nhân viên");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processLoginSuccessful() {
        lblMaNV.setText(ShareData.nguoiDangNhap.getTaiKhoan());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		pnlThongTinNV = new javax.swing.JPanel();
		lblTenNV = new javax.swing.JLabel();
		lblMaNV = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		lblChucVu = new javax.swing.JLabel();
		lblSĐT = new javax.swing.JLabel();
		scrollPaneWin111 = new com.mycompany.quanlybansach.raven.scroll.win11.ScrollPaneWin11();
		menu1 = new com.mycompany.quanlybansach.raven.menu.Menu();
		pnlBody = new javax.swing.JPanel();
		jPanel4 = new javax.swing.JPanel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setBackground(new java.awt.Color(99, 183, 183));

		jPanel1.setBackground(new java.awt.Color(99, 183, 183));

		pnlThongTinNV.setBackground(new java.awt.Color(255, 255, 255));

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-name-48.png"))); // NOI18N

		javax.swing.GroupLayout pnlThongTinNVLayout = new javax.swing.GroupLayout(pnlThongTinNV);
		pnlThongTinNV.setLayout(pnlThongTinNVLayout);
		pnlThongTinNVLayout.setHorizontalGroup(pnlThongTinNVLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlThongTinNVLayout.createSequentialGroup().addGap(16, 16, 16).addGroup(pnlThongTinNVLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel1)
						.addGroup(pnlThongTinNVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(lblSĐT, javax.swing.GroupLayout.PREFERRED_SIZE, 158,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(pnlThongTinNVLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
										.addComponent(lblChucVu, javax.swing.GroupLayout.Alignment.LEADING,
												javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
										.addComponent(lblMaNV, javax.swing.GroupLayout.Alignment.LEADING,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblTenNV, javax.swing.GroupLayout.Alignment.LEADING,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
						.addContainerGap(17, Short.MAX_VALUE)));
		pnlThongTinNVLayout
				.setVerticalGroup(
						pnlThongTinNVLayout
								.createParallelGroup(
										javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(pnlThongTinNVLayout.createSequentialGroup().addComponent(jLabel1)
										.addGap(24, 24, 24)
										.addComponent(lblTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 28,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(18, 18, 18)
										.addComponent(lblMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 29,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(lblChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 29,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(18, 18, 18)
										.addComponent(lblSĐT, javax.swing.GroupLayout.PREFERRED_SIZE, 28,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		scrollPaneWin111.setViewportView(menu1);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
								.addComponent(scrollPaneWin111, javax.swing.GroupLayout.Alignment.LEADING,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)
								.addComponent(pnlThongTinNV, javax.swing.GroupLayout.Alignment.LEADING,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		jPanel1Layout
				.setVerticalGroup(
						jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addComponent(scrollPaneWin111, javax.swing.GroupLayout.PREFERRED_SIZE, 483,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(pnlThongTinNV, javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addContainerGap()));

		pnlBody.setLayout(new java.awt.BorderLayout());

		jPanel4.setBackground(new java.awt.Color(99, 183, 183));

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 1015, Short.MAX_VALUE));
		jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 736, Short.MAX_VALUE));

		pnlBody.add(jPanel4, java.awt.BorderLayout.LINE_START);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(pnlBody, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
						Short.MAX_VALUE)
				.addGroup(layout.createSequentialGroup().addContainerGap().addComponent(pnlBody,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addContainerGap()));

		pack();
	}// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        // <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
        // (optional) ">
        /*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        new splashscreen.SplashScreen(null, true).setVisible(true);
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GiaoDienChinh.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GiaoDienChinh.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GiaoDienChinh.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GiaoDienChinh.class.getName()).log(java.util.logging.Level.SEVERE, null,
                    ex);
        }
        // </editor-fold>
        // </editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GiaoDienChinh().setVisible(true);
            }
        });
    }

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JLabel lblChucVu;
	private javax.swing.JLabel lblMaNV;
	private javax.swing.JLabel lblSĐT;
	private javax.swing.JLabel lblTenNV;
	private com.mycompany.quanlybansach.raven.menu.Menu menu1;
	private javax.swing.JPanel pnlBody;
	private javax.swing.JPanel pnlThongTinNV;
	private com.mycompany.quanlybansach.raven.scroll.win11.ScrollPaneWin11 scrollPaneWin111;
	// End of variables declaration//GEN-END:variables
}

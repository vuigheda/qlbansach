/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.ChiTietDatSach;
import com.mycompany.quanlybansach.entity.DatSach;
import com.mycompany.quanlybansach.entity.SanPham;

/**
 *
 * @author quang
 */
public class ChiTietDatSachDAO {
	private Connection con;

	public ChiTietDatSachDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	public boolean ThemCTDatSach(ChiTietDatSach ctds) {

		try {
			String sql = "INSERT INTO [dbo].[ChiTietDatSach]\r\n" + "           ([MaCTDS]\r\n"
					+ "           ,[MaSP]\r\n" + "           ,[MaDS]\r\n" + "           ,[SoLuong]\r\n"
					+ "           ,[DonGia])\r\n" + "     VALUES\r\n" + "           (?,?,?,?,?)";

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, ctds.getMaCTDS());
			stmt.setString(2, ctds.getMaSP().getMaSP());
			stmt.setString(3, ctds.getMaDS().getMaDS());
			stmt.setInt(4, ctds.getSoLuong());
			stmt.setDouble(5, ctds.getDonGia());

			int n = stmt.executeUpdate();

			return n > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	public boolean update(ChiTietDatSach ctds) throws SQLException {

		String sql = "UPDATE [dbo].[ChiTietDatSach]\r\n" + "   SET [MaCTDS] = ?\r\n" + "      ,[MaSP] = ?\r\n"
				+ "      ,[MaDS] = ?\r\n" + "      ,[SoLuong] = ?\r\n" + "      ,[DonGia] = ?\r\n"
				+ " WHERE MaCTDS = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, ctds.getMaCTDS());
		stmt.setString(2, ctds.getMaSP().getMaSP());
		stmt.setString(3, ctds.getMaDS().getMaDS());
		stmt.setInt(4, ctds.getSoLuong());
		stmt.setDouble(5, ctds.getDonGia());
		stmt.setString(6, ctds.getMaCTDS());

		return stmt.executeUpdate() > 0;
	}

	public List<ChiTietDatSach> LoadCTDatSach() throws SQLException {
		String sql = "SELECT [MaCTDS]\r\n" + "      ,[MaSP]\r\n" + "      ,[MaDS]\r\n" + "      ,[SoLuong]\r\n"
				+ "      ,[DonGia]\r\n" + "  FROM [dbo].[ChiTietDatSach]";
		List<ChiTietDatSach> dsCTDS = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ChiTietDatSach chiTietDS = new ChiTietDatSach();
			DatSach ds = new DatSach();
			SanPham sp = new SanPham();

			chiTietDS.setMaCTDS(rs.getString("MaCTDS"));
			ds.setMaDS(rs.getString("MaDS"));
			sp.setMaSP(rs.getString("MaSP"));
			chiTietDS.setMaDS(ds);
			chiTietDS.setMaSP(sp);
			chiTietDS.setSoLuong(rs.getInt("SoLuong"));
			chiTietDS.setDonGia(rs.getDouble("DonGia"));

			dsCTDS.add(chiTietDS);
		}

		return dsCTDS;
	}

	public String generateMaCTDS() throws SQLException {
		String MaCTDS = null;
		String prefix = "CTDS";
		String sql = "SELECT MAX(MaCTDS) FROM ChiTietDatSach";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);

		rs.next();
		String maxMaCTDS = rs.getString(1);
		int index = 1;

		if (maxMaCTDS != null) {
			String numericPart = maxMaCTDS.substring(prefix.length()).trim();
			index = Integer.parseInt(numericPart) + 1;
		}

		MaCTDS = prefix + String.format("%03d", index);

		return MaCTDS;
	}
	
	public List<CTDSDTO> DanhSachCTHoaDonIsMaHD(String maDS) throws SQLException {
        String sql = "SELECT    dbo.ChiTietDatSach.MaSP, dbo.SanPham.TenSP, dbo.ChiTietDatSach.SoLuong, dbo.SanPham.DonGia, dbo.ChiTietDatSach.DonGia AS ThanhTien\r\n"
        		+ "FROM         dbo.ChiTietDatSach INNER JOIN\r\n"
        		+ "                      dbo.SanPham ON dbo.ChiTietDatSach.MaSP = dbo.SanPham.MaSP\r\n"
        		+ "WHERE MaDS = ?";
        List<CTDSDTO> dsCTDS = new ArrayList<>();
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maDS);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
        	CTDSDTO ctdsDTO = new CTDSDTO();      
        	
        	ctdsDTO.setMaSP(rs.getString("MaSP"));
        	ctdsDTO.setTenSP(rs.getString("TenSP"));
        	ctdsDTO.setSoLuong(rs.getInt("SoLuong"));
        	ctdsDTO.setDonGia(rs.getDouble("DonGia"));
        	ctdsDTO.setThanhTien(rs.getDouble("ThanhTien"));       	
        	dsCTDS.add(ctdsDTO);
        }

        return dsCTDS;
    }

	public class CTDSDTO {
		private String maSP;
		private String tenSP;
		private int soLuong;
		private double donGia;
		private double thanhTien;

		public CTDSDTO() {
			super();

		}

		public CTDSDTO(String maSP, String tenSP, int soLuong, double donGia, double thanhTien) {
			super();
			this.maSP = maSP;
			this.tenSP = tenSP;
			this.soLuong = soLuong;
			this.donGia = donGia;
			this.thanhTien = thanhTien;
		}

		public String getMaSP() {
			return maSP;
		}

		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}

		public String getTenSP() {
			return tenSP;
		}

		public void setTenSP(String tenSP) {
			this.tenSP = tenSP;
		}

		public int getSoLuong() {
			return soLuong;
		}

		public void setSoLuong(int soLuong) {
			this.soLuong = soLuong;
		}

		public double getDonGia() {
			return donGia;
		}

		public void setDonGia(double donGia) {
			this.donGia = donGia;
		}

		public double getThanhTien() {
			return thanhTien;
		}

		public void setThanhTien(double thanhTien) {
			this.thanhTien = thanhTien;
		}
	}
}

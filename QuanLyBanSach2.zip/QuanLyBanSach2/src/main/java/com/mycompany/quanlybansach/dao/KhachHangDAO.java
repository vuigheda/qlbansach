/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */
import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.KhachHang;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class KhachHangDAO {

	private Connection con;

	public KhachHangDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

//Them khach hang
	public boolean ThemKH(KhachHang kh) {

		try {
			String sql = "INSERT INTO [dbo].[KhachHang]\r\n" + "           ([MaKH]\r\n" + "           ,[TenKH]\r\n"
					+ "           ,[DiaChi]\r\n" + "           ,[GioiTinh]\r\n" + "           ,[SDT])\r\n"
					+ "     VALUES\r\n" + "           (?, ?, ?, ?, ?)";

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, kh.getMaKH());
			stmt.setString(2, kh.getTenKH());
			stmt.setString(3, kh.getDiaChi());
			stmt.setInt(4, kh.getGioiTinh());
			stmt.setString(5, kh.getsDT());

			int n = stmt.executeUpdate();

			return n > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

//Update khach hang
	public boolean update(KhachHang kh) throws SQLException {

		String sql = "UPDATE [dbo].[KhachHang]\r\n" + "   SET [MaKH] = ?\r\n" + "      ,[TenKH] = ?\r\n"
				+ "      ,[DiaChi] = ?\r\n" + "      ,[GioiTinh] = ?\r\n" + "      ,[SDT] = ?\r\n" + " WHERE MaKH = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, kh.getMaKH());
		stmt.setString(2, kh.getTenKH());
		stmt.setString(3, kh.getDiaChi());
		stmt.setInt(4, kh.getGioiTinh());
		stmt.setString(5, kh.getsDT());
		stmt.setString(6, kh.getMaKH());

		return stmt.executeUpdate() > 0;

	}

//Xoa khach hang bang maKH
	public boolean deleteMaKH(String maKH) throws SQLException {

		String sql = "DELETE FROM [dbo].[KhachHang]\r\n" + "		WHERE MaKH = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maKH);

		return stmt.executeLargeUpdate() > 0;

	}

// Xoa khach hang bang SDT
	public boolean deleteSDT(String sdt) throws SQLException {

		String sql = "DELETE FROM [dbo].[KhachHang]\r\n" + "		WHERE SDT = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, sdt);

		return stmt.executeLargeUpdate() > 0;

	}

//Hien thi danh sach khach hang
	public List<KhachHang> LoadKhachHang() throws SQLException {
		String sql = "SELECT * FROM [dbo].[KhachHang]";
		List<KhachHang> dsKH = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String maKH = rs.getString(1);
			String tenKH = rs.getString(2);
			String diaChi = rs.getString(3);
			int gioiTinh = rs.getInt(4);
			String sDT = rs.getString(5);

			KhachHang kh = new KhachHang(maKH, tenKH, diaChi, gioiTinh, sDT);
			dsKH.add(kh);
		}

		return dsKH;

	}

// Tim kiem khach hang bang sdt
	public KhachHang getKhachHangTheoSDT(String sDT) throws SQLException {
		String sql = "SELECT * FROM [dbo].[KhachHang] WHERE SDT = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, sDT);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String maKH = rs.getString(1);
			String tenKH = rs.getString(2);
			String diaChi = rs.getString(3);
			int gioiTinh = rs.getInt(4);

			KhachHang kh = new KhachHang(maKH, tenKH, diaChi, gioiTinh, sDT);
			return kh;
		}

		return null;
	}

	public KhachHang getKhachHangTheoTenKH(String tenKH) throws SQLException {
		String sql = "SELECT * FROM [dbo].[KhachHang] WHERE TenKH LIKE N'%' + ? + '%'";


		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, tenKH);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			KhachHang kh = new KhachHang();
			kh.setMaKH(rs.getString("MaKH"));
			kh.setTenKH(tenKH);
			kh.setDiaChi(rs.getString("DiaChi"));
			kh.setGioiTinh(rs.getInt("GioiTinh"));
			kh.setsDT(rs.getString("SDT"));
			return kh;
		}

		return null;
	}

//Tim kiem khach hang bang maKH
	public KhachHang getKhachHangTheoMaKH(String maKH) throws SQLException {
		String sql = "SELECT * FROM [dbo].[KhachHang] WHERE MaKH = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maKH);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String tenKH = rs.getString(2);
			String diaChi = rs.getString(3);
			int gioiTinh = rs.getInt(4);
			String sDT = rs.getString(5);
			KhachHang kh = new KhachHang(maKH, tenKH, diaChi, gioiTinh, sDT);
			return kh;
		}

		return null;
	}

	public List<String> DanhSachTenKH() throws SQLException {
		String sql = "SELECT TenKH FROM [dbo].[KhachHang]";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		List<String> khList = new ArrayList<String>();
		while (rs.next()) {
			String nxb = rs.getString("TenKH");
			khList.add(nxb);
		}
		return khList;
	}

	public String getMaKH(String tenKH) throws SQLException {
		String sql = "SELECT MaKH FROM [dbo].[KhachHang] WHERE TenKH LIKE N'%' + ? + '%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, tenKH);
		ResultSet rs = pstmt.executeQuery();
		String maKH = null;
		if (rs.next()) {
			maKH = rs.getString("MaKH");
		}
		return maKH;
	}
	
	public String getKHisSDT(String sdt) throws SQLException {
		String sql = "SELECT MaKH FROM [dbo].[KhachHang] WHERE SDT LIKE N'%' + ? + '%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, sdt);
		ResultSet rs = pstmt.executeQuery();
		String maKH = null;
		if (rs.next()) {
			maKH = rs.getString("MaKH");
		}
		return maKH;
	}

	public boolean checkSDT(String sdt) throws SQLException {
		String sql = "SELECT COUNT(*) FROM KhachHang WHERE SDT = ?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setString(1, sdt);
		ResultSet rs = statement.executeQuery();
		if (rs.next()) {
			int count = rs.getInt(1);
			if (count == 0)
				return true;
			else
				return false;
		}
		return false;
	}

}

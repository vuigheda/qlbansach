/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

/**
 *
 * @author quang
 */


public class ChiTietDatSach {
	private String maCTDS;
	private DatSach maDS;
	private SanPham maSP;
	private int soLuong;
	private double donGia;

	public ChiTietDatSach() {
		super();
	}

	public ChiTietDatSach(String maCTDS, DatSach maDS, SanPham maSP, int soLuong, double donGia) {
		super();
		this.maCTDS = maCTDS;
		this.maDS = maDS;
		this.maSP = maSP;
		this.soLuong = soLuong;
		this.donGia = donGia;
	}

	public String getMaCTDS() {
		return maCTDS;
	}

	public void setMaCTDS(String maCTDS) {
		this.maCTDS = maCTDS;
	}

	public DatSach getMaDS() {
		return maDS;
	}

	public void setMaDS(DatSach maDS) {
		this.maDS = maDS;
	}

	public SanPham getMaSP() {
		return maSP;
	}

	public void setMaSP(SanPham maSP) {
		this.maSP = maSP;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}

	public double getDonGia() {
		return donGia;
	}

	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}

	@Override
	public String toString() {
		return "ChiTietDatSach [maCTDS=" + maCTDS + ", maDS=" + maDS + ", maSP=" + maSP + ", soLuong=" + soLuong
				+ ", donGia=" + donGia + "]";
	}

}

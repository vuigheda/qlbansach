/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.DungCuHocTap;

/**
 *
 * @author quang
 */
public class DungCuHocTapDAO {
	private Connection con;

	public DungCuHocTapDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	public boolean insert(DungCuHocTap dcht) throws SQLException {
		String sql = "INSERT INTO [dbo].[DungCuHocTap]\r\n" + "           ([MaSP]\r\n" + "           ,[MaNCC])\r\n"
				+ "     VALUES\r\n" + "           (?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, dcht.getMaSP());
		stmt.setString(2, dcht.getMaNCC().getMaNCC());

		return stmt.executeUpdate() > 0;
	}

	public boolean delete(String maSP) throws SQLException {
		String sql = "DELETE FROM [dbo].[DungCuHocTap]\r\n" + "      WHERE  MaSP = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maSP);
		return stmt.executeLargeUpdate() > 0;
	}

	public boolean update(DungCuHocTap dcht) throws SQLException {
		String sql = "UPDATE [dbo].[DungCuHocTap]\r\n"
				+ "   SET [MaSP] = ?\r\n"
				+ "      ,[MaNCC] = ?\r\n"
				+ " WHERE MaSP = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, dcht.getMaSP());
		stmt.setString(2, dcht.getMaNCC().getMaNCC());
		stmt.setString(3, dcht.getMaSP());

		return stmt.executeUpdate() > 0;
	}
	
	
	public DCHTDTO getDungCuHocTap(String maSP) throws SQLException {
	    DCHTDTO dcHocTap = null;

	    String query = "SELECT	MaSP,TenNCC FROM [dbo].[DungCuHocTap] dcht\r\n"
	    		+ "INNER JOIN [dbo].[NhaCungCap] ncc ON dcht.MaNCC = ncc.MaNCC\r\n"
	    		+ "WHERE MaSP = ?";
	    PreparedStatement ps = con.prepareStatement(query);
	    ps.setString(1, maSP);
	    ResultSet rs = ps.executeQuery();

	    if (rs.next()) {
	        String maSPResult = rs.getString("MaSP");
	        String tenNCC = rs.getString("TenNCC");

	        dcHocTap = new DCHTDTO(maSPResult, tenNCC);
	    }

	    return dcHocTap;
	}
	
	public class DCHTDTO {
		private String maSP;
		private String tenNCC;

		public DCHTDTO() {
			super();
		}

		public DCHTDTO(String maSP, String tenNCC) {
			super();
			this.maSP = maSP;
			this.tenNCC = tenNCC;
		}

		public String getMaSP() {
			return maSP;
		}

		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}

		public String getTenNCC() {
			return tenNCC;
		}

		public void setTenNCC(String tenNCC) {
			this.tenNCC = tenNCC;
		}

	}

}

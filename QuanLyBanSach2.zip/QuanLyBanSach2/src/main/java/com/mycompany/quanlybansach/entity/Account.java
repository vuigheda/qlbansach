/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;
import java.util.Objects;
/**
 *
 * @author quang
 */

public class Account {
	private String taiKhoan;
	private String matKhau;
	private int quyenHan;

	public Account() {
		super();
	}

	public Account(String taiKhoan, String matKhau, int quyenHan) {
		super();
		this.taiKhoan = taiKhoan;
		this.matKhau = matKhau;
		this.quyenHan = quyenHan;
	}

	public Account(String taiKhoan) {
		super();
		this.taiKhoan = taiKhoan;
	}

	public String getTaiKhoan() {
		return taiKhoan;
	}

	public void setTaiKhoan(String taiKhoan) {
		this.taiKhoan = taiKhoan;
	}

	public String getMatKhau() {
		return matKhau;
	}

	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}

	public int getQuyenHan() {
		return quyenHan;
	}

	@Override
	public String toString() {
		return "Account [taiKhoan=" + taiKhoan + ", matKhau=" + matKhau + ", quyenHan=" + quyenHan + "]";
	}
	
	public void setQuyenHan(int quyenHan) {
		this.quyenHan = quyenHan;
	}

	@Override
	public int hashCode() {
		return Objects.hash(taiKhoan);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		return Objects.equals(taiKhoan, other.taiKhoan);
	}

}

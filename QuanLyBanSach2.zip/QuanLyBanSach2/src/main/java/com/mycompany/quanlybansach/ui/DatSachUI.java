/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.quanlybansach.ui;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.connectDB.DataValidator;
import com.mycompany.quanlybansach.connectDB.MessageDialogConnectDB;
import com.mycompany.quanlybansach.dao.ChiTietDatSachDAO;
import com.mycompany.quanlybansach.dao.DatSachDAO;
import com.mycompany.quanlybansach.dao.KhachHangDAO;
import com.mycompany.quanlybansach.dao.LoaiSachDAO;
import com.mycompany.quanlybansach.dao.NhaXuatBanDAO;
import com.mycompany.quanlybansach.dao.SanPhamDAO;
import com.mycompany.quanlybansach.dao.TacGiaDAO;
import com.mycompany.quanlybansach.dao.SanPhamDAO.BookDTO;
import com.mycompany.quanlybansach.entity.ChiTietDatSach;
import com.mycompany.quanlybansach.entity.DatSach;
import com.mycompany.quanlybansach.entity.KhachHang;
import com.mycompany.quanlybansach.entity.NhanVien;
import com.mycompany.quanlybansach.entity.Regex;
import com.mycompany.quanlybansach.entity.SanPham;
import com.mycompany.quanlybansach.ui.support.TableCustom;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author quang
 */
public class DatSachUI extends javax.swing.JPanel {

	/**
	 * Creates new form DatSach
	 */
	private static final long serialVersionUID = 1L;
	private DefaultTableModel tblModel;
	private DefaultTableModel tblModel1;
	private DefaultTableModel tblModel2;

	@SuppressWarnings("unused")
	private GiaoDienChinh giaoDienChinh;
	private Regex regex;
	private NhanVien maNV;
	private String maDS;

	public DatSachUI(NhanVien maNV) throws SQLException {
		this.maNV = maNV;
		regex = new Regex();
		initComponents();

		KhachHangDAO daoKH = new KhachHangDAO();
		List<String> dsTenKH = new ArrayList<String>();
		dsTenKH = daoKH.DanhSachTenKH();
		for (String kh : dsTenKH) {
			jCbTenKH.addItem(kh);
		}

		NhaXuatBanDAO dao = new NhaXuatBanDAO();
		List<String> dsTenNXB = new ArrayList<String>();
		dsTenNXB = dao.DanhSachTenNXB();
		for (String nxb : dsTenNXB) {
			jCbNXB.addItem(nxb);
		}

		LoaiSachDAO loaiSachDAO = new LoaiSachDAO();
		List<String> dsTenTheLoai = new ArrayList<String>();
		dsTenTheLoai = loaiSachDAO.DanhSachTenTheLoai();
		for (String theLoai : dsTenTheLoai) {
			jCbLS.addItem(theLoai);
		}

		TacGiaDAO tacGiaDAO = new TacGiaDAO();
		List<String> dsTacGia = new ArrayList<String>();
		dsTacGia = tacGiaDAO.DanhSachTenTacGia();
		for (String tacGia : dsTacGia) {
			jCbTG.addItem(tacGia);
		}

		initTable();
		initTable1();
		initTable2();

		TableCustom.apply(jSPSanPham, TableCustom.TableType.DEFAULT);
		jSPSanPham.getVerticalScrollBar().setUnitIncrement(20);
		TableCustom.apply(jSPDanhSachHoaDon, TableCustom.TableType.DEFAULT);
		jSPDanhSachHoaDon.getVerticalScrollBar().setUnitIncrement(20);
		TableCustom.apply(jSPGioHang, TableCustom.TableType.DEFAULT);
		jSPGioHang.getVerticalScrollBar().setUnitIncrement(20);
		showSanPham();
	}

	@SuppressWarnings("unused")
	private void initTable() {
		tblModel = new DefaultTableModel();
//		tblModel.setColumnIdentifiers(new String[] { "Mã sách", "Tên sách", "Thể loại", "Tác giả", "Nhà xuất bản" });
		tblModel.setColumnIdentifiers(new String[] { "Mã sách", "Tên sách" });
		tblSanPham.setModel(tblModel);

	}

	@SuppressWarnings("unused")
	private void initTable1() {
		tblModel1 = new DefaultTableModel();
		tblModel1.setColumnIdentifiers(new String[] { "Mã sách", "Tên sách", "Thể loại", "Tác giả", "Nhà xuất bản",
				"Số lượng", "Đơn giá", "Thành tiền" });
		tblDanhSachSPDat.setModel(tblModel1);

	}

	@SuppressWarnings("unused")
	private void initTable2() {
		tblModel2 = new DefaultTableModel();
		tblModel2.setColumnIdentifiers(new String[] { "Mã sách", "Tên sách" });
		tblGioHang.setModel(tblModel2);

	}

	public void showSanPham() throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.getBooksInfo();
		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
			tblModel.fireTableDataChanged();
		}
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	// <editor-fold defaultstate="collapsed" desc="Generated
	// <editor-fold defaultstate="collapsed" desc="Generated
	// <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jPanel2 = new javax.swing.JPanel();
		lblQuanLyHoaDon = new javax.swing.JLabel();
		pnlKH = new com.mycompany.quanlybansach.ui.support.PanelRound();
		lblTenKH = new javax.swing.JLabel();
		lblSDT = new javax.swing.JLabel();
		txtDiaChi = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		lblDiaChi = new javax.swing.JLabel();
		txtSDT = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		jCbTenKH = new javax.swing.JComboBox<>();
		btnThemKH = new com.mycompany.quanlybansach.ui.support.ButtonGradient();
		pnlHoaDon = new com.mycompany.quanlybansach.ui.support.PanelRound();
		lblMaSP = new javax.swing.JLabel();
		lblThanhTien = new javax.swing.JLabel();
		txtSoLuong = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		txtMaSP = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		lblSoLuong = new javax.swing.JLabel();
		txtDonGia = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		btnInHoaDon = new com.mycompany.quanlybansach.ui.support.ButtonGradient();
		lblDonGia = new javax.swing.JLabel();
		txtThanhTien = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		btnTim = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
		lblHinhThucThanhToan = new javax.swing.JLabel();
		jCbHinhThucThanhToan = new javax.swing.JComboBox<>();
		btnThanhToan = new com.mycompany.quanlybansach.ui.support.ButtonGradient();
		pnlCha = new com.mycompany.quanlybansach.ui.support.PanelRound();
		pnlNXB = new com.mycompany.quanlybansach.ui.support.PanelRound();
		lblNXB = new javax.swing.JLabel();
		lblTG = new javax.swing.JLabel();
		lblLS = new javax.swing.JLabel();
		jCbNXB = new javax.swing.JComboBox<>();
		jCbTG = new javax.swing.JComboBox<>();
		jCbLS = new javax.swing.JComboBox<>();
		jSPDanhSachHoaDon = new javax.swing.JScrollPane();
		tblDanhSachSPDat = new javax.swing.JTable();
		pnlSP = new javax.swing.JPanel();
		jSPSanPham = new javax.swing.JScrollPane();
		tblSanPham = new javax.swing.JTable();
		panelRound21 = new com.mycompany.quanlybansach.ui.support.PanelRound2();
		lblTongTien = new javax.swing.JLabel();
		lblTienKhachTra = new javax.swing.JLabel();
		lblSoDu = new javax.swing.JLabel();
		txtTienKhachTra = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		txtSoDu = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
		lblTT = new javax.swing.JLabel();
		jSPGioHang = new javax.swing.JScrollPane();
		tblGioHang = new javax.swing.JTable();

		jPanel2.setBackground(new java.awt.Color(99, 183, 183));
		jPanel2.setPreferredSize(new java.awt.Dimension(1274, 578));

		lblQuanLyHoaDon.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
		lblQuanLyHoaDon.setText("ĐẶT SÁCH");

		pnlKH.setBackground(new java.awt.Color(255, 255, 255));
		pnlKH.setRoundBottomLeft(50);
		pnlKH.setRoundBottomRight(50);
		pnlKH.setRoundTopLeft(50);
		pnlKH.setRoundTopRight(50);

		lblTenKH.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblTenKH.setText("Tên KH:");

		lblSDT.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblSDT.setText("SĐT:");

		lblDiaChi.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblDiaChi.setText("Địa chỉ:");

		txtSDT.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				txtSDTKeyTyped(evt);
			}
		});

		jCbTenKH.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		jCbTenKH.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jCbTenKHActionPerformed(evt);
			}
		});

		btnThemKH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-plus-24.png"))); // NOI18N
		btnThemKH.setText("Thêm khách hàng");
		btnThemKH.setColor1(new java.awt.Color(0, 172, 126));
		btnThemKH.setColor2(new java.awt.Color(0, 172, 126));
		btnThemKH.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					btnThemKHActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		javax.swing.GroupLayout pnlKHLayout = new javax.swing.GroupLayout(pnlKH);
		pnlKH.setLayout(pnlKHLayout);
		pnlKHLayout.setHorizontalGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlKHLayout.createSequentialGroup().addContainerGap()
						.addGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(lblDiaChi).addComponent(lblSDT).addComponent(lblTenKH))
						.addGap(18, 18, 18)
						.addGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
								.addComponent(btnThemKH, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
								.addComponent(jCbTenKH, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(txtSDT, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(txtDiaChi, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		pnlKHLayout.setVerticalGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlKHLayout.createSequentialGroup().addGap(19, 19, 19)
						.addGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jCbTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(pnlKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(btnThemKH, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pnlHoaDon.setBackground(new java.awt.Color(255, 255, 255));
		pnlHoaDon.setRoundBottomLeft(50);
		pnlHoaDon.setRoundBottomRight(50);
		pnlHoaDon.setRoundTopLeft(50);
		pnlHoaDon.setRoundTopRight(50);

		lblMaSP.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblMaSP.setText("Mã sản phẩm:");

		lblThanhTien.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblThanhTien.setText("Thành tiền:");

		txtSoLuong.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				try {
					txtSoLuongKeyTyped(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		txtMaSP.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				try {
					txtMaSPKeyTyped(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		lblSoLuong.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblSoLuong.setText("Số lượng:");

		txtDonGia.setEnabled(false);

		btnInHoaDon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-print-24.png"))); // NOI18N
		btnInHoaDon.setText("In hóa đơn");
		btnInHoaDon.setColor1(new java.awt.Color(0, 172, 126));
		btnInHoaDon.setColor2(new java.awt.Color(0, 172, 126));
		btnInHoaDon.setEnabled(false);
		btnInHoaDon.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnInHoaDonActionPerformed(evt);
			}
		});

		lblDonGia.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblDonGia.setText("Đơn giá:");

		txtThanhTien.setEnabled(false);

		btnTim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search-icon-16.png"))); // NOI18N
		btnTim.setText("Tìm");
		btnTim.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					btnTimActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		lblHinhThucThanhToan.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblHinhThucThanhToan.setText("HT thanh toán:");

		jCbHinhThucThanhToan.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		jCbHinhThucThanhToan.setModel(new javax.swing.DefaultComboBoxModel<>(
				new String[] { "Hình thức thanh toán", "Trả trước", "Trả sau" }));
		jCbHinhThucThanhToan.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jCbHinhThucThanhToanActionPerformed(evt);
			}
		});

		btnThanhToan.setText("Đặt");
		btnThanhToan.setColor1(new java.awt.Color(0, 172, 126));
		btnThanhToan.setColor2(new java.awt.Color(0, 172, 126));
		btnThanhToan.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				btnThanhToanMouseClicked(evt);
			}
		});
		btnThanhToan.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					btnThanhToanActionPerformed(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		javax.swing.GroupLayout pnlHoaDonLayout = new javax.swing.GroupLayout(pnlHoaDon);
		pnlHoaDon.setLayout(pnlHoaDonLayout);
		pnlHoaDonLayout.setHorizontalGroup(pnlHoaDonLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHoaDonLayout.createSequentialGroup().addGap(19, 19, 19)
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(lblDonGia).addComponent(lblMaSP).addComponent(lblThanhTien)
								.addComponent(lblHinhThucThanhToan))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(btnInHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 129,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(pnlHoaDonLayout.createSequentialGroup().addGroup(pnlHoaDonLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 106,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 106,
												javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(pnlHoaDonLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(pnlHoaDonLayout.createSequentialGroup()
														.addComponent(lblSoLuong)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(txtSoLuong,
																javax.swing.GroupLayout.PREFERRED_SIZE, 70,
																javax.swing.GroupLayout.PREFERRED_SIZE))
												.addComponent(btnTim, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addComponent(txtThanhTien, javax.swing.GroupLayout.PREFERRED_SIZE, 251,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(pnlHoaDonLayout.createSequentialGroup()
										.addComponent(jCbHinhThucThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 190,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(btnThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 72,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		pnlHoaDonLayout.setVerticalGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHoaDonLayout.createSequentialGroup().addContainerGap(20, Short.MAX_VALUE)
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(btnTim, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(16, 16, 16)
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(txtThanhTien, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblThanhTien, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(pnlHoaDonLayout.createSequentialGroup().addGap(10, 10, 10).addComponent(
										lblHinhThucThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(pnlHoaDonLayout.createSequentialGroup().addGap(18, 18, 18)
										.addGroup(pnlHoaDonLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jCbHinhThucThanhToan,
														javax.swing.GroupLayout.PREFERRED_SIZE, 40,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(btnThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 36,
														javax.swing.GroupLayout.PREFERRED_SIZE))))
						.addGap(12, 12, 12).addComponent(btnInHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 28,
								javax.swing.GroupLayout.PREFERRED_SIZE)));

		pnlCha.setBackground(new java.awt.Color(255, 255, 255));
		pnlCha.setRoundBottomLeft(50);
		pnlCha.setRoundBottomRight(50);
		pnlCha.setRoundTopLeft(50);
		pnlCha.setRoundTopRight(50);
		pnlCha.setLayout(null);

		pnlNXB.setBackground(new java.awt.Color(255, 255, 255));
		pnlNXB.setRoundBottomLeft(50);
		pnlNXB.setRoundBottomRight(50);
		pnlNXB.setRoundTopLeft(50);
		pnlNXB.setRoundTopRight(50);

		lblNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblNXB.setText("Nhà xuất bản:");

		lblTG.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblTG.setText("Tác giả: ");

		lblLS.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblLS.setText("Loại sách:");

		jCbNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		jCbNXB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chọn nhà xuất bản" }));
		jCbNXB.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jCbNXBActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		jCbTG.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		jCbTG.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chọn tác giả" }));
		jCbTG.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jCbTGActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		jCbLS.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		jCbLS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chọn loại sách" }));
		jCbLS.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				try {
					jCbLSActionPerformed(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		javax.swing.GroupLayout pnlNXBLayout = new javax.swing.GroupLayout(pnlNXB);
		pnlNXB.setLayout(pnlNXBLayout);
		pnlNXBLayout.setHorizontalGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlNXBLayout.createSequentialGroup().addGap(15, 15, 15)
						.addGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(lblNXB)
								.addComponent(lblTG, javax.swing.GroupLayout.PREFERRED_SIZE, 55,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblLS))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(jCbLS, javax.swing.GroupLayout.PREFERRED_SIZE, 260,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jCbNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 260,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jCbTG, javax.swing.GroupLayout.PREFERRED_SIZE, 260,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		pnlNXBLayout.setVerticalGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlNXBLayout.createSequentialGroup().addContainerGap()
						.addGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jCbNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblTG, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jCbTG, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
						.addGroup(pnlNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblLS, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jCbLS, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap()));

		pnlCha.add(pnlNXB);
		pnlNXB.setBounds(0, 0, 380, 150);

		tblDanhSachSPDat.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		tblDanhSachSPDat.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null } },
				new String[] { "Mã sách", "Tên sách", "Thể loại", "Tác giả", "Nhà xuất bản", "Đơn giá", "Số lượng",
						"Thành tiền" }));
		jSPDanhSachHoaDon.setViewportView(tblDanhSachSPDat);

		pnlSP.setBackground(new java.awt.Color(255, 255, 255));
		pnlSP.setToolTipText("");
		pnlSP.setBorder(BorderFactory.createTitledBorder("Danh sách sản phẩm"));

		tblSanPham.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null, null, null, null }, { null, null, null, null, null },
						{ null, null, null, null, null }, { null, null, null, null, null } },
				new String[] { "Mã sách", "Tên sách", "Thể loại", "Tác giả", "Nhà xuất bản" }));
		tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					tblSanPhamMouseClicked(evt);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jSPSanPham.setViewportView(tblSanPham);

		javax.swing.GroupLayout pnlSPLayout = new javax.swing.GroupLayout(pnlSP);
		pnlSP.setLayout(pnlSPLayout);
		pnlSPLayout.setHorizontalGroup(
				pnlSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jSPSanPham));
		pnlSPLayout.setVerticalGroup(pnlSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlSPLayout.createSequentialGroup().addContainerGap().addComponent(jSPSanPham,
						javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)));

		panelRound21.setBackground(new java.awt.Color(255, 255, 255));

		lblTongTien.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblTongTien.setText("Tổng tiền: ");

		lblTienKhachTra.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblTienKhachTra.setText("Tiền khách trả: ");

		lblSoDu.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		lblSoDu.setText("Số dư: ");

		txtTienKhachTra.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent evt) {
				try {
					txtTienKhachTraKeyTyped(evt);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		txtSoDu.setEnabled(false);

		lblTT.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N

		javax.swing.GroupLayout panelRound21Layout = new javax.swing.GroupLayout(panelRound21);
		panelRound21.setLayout(panelRound21Layout);
		panelRound21Layout.setHorizontalGroup(panelRound21Layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(panelRound21Layout.createSequentialGroup().addGap(18, 18, 18)
						.addGroup(panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(lblTienKhachTra)
								.addComponent(lblTongTien, javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(lblSoDu, javax.swing.GroupLayout.Alignment.TRAILING))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(txtTienKhachTra, javax.swing.GroupLayout.PREFERRED_SIZE, 159,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtSoDu, javax.swing.GroupLayout.PREFERRED_SIZE, 159,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblTT))
						.addContainerGap(42, Short.MAX_VALUE)));
		panelRound21Layout.setVerticalGroup(panelRound21Layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(panelRound21Layout.createSequentialGroup().addContainerGap()
						.addGroup(panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblTT, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblTienKhachTra, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtTienKhachTra, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblSoDu, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtSoDu, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap(22, Short.MAX_VALUE)));

		tblGioHang.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
		tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null }, { null, null }, { null, null }, { null, null } },
				new String[] { "Mã sách", "Tên sách" }));
		tblGioHang.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				try {
					tblGioHangMouseClicked(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		jSPGioHang.setViewportView(tblGioHang);

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
						jPanel2Layout.createSequentialGroup()
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblQuanLyHoaDon).addGap(618, 618, 618))
				.addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
						.addComponent(jSPDanhSachHoaDon, javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(jPanel2Layout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
										.addComponent(panelRound21, javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(pnlKH, javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(jPanel2Layout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
										.addComponent(pnlHoaDon, javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(pnlCha, javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(jPanel2Layout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
										.addComponent(jSPGioHang, javax.swing.GroupLayout.DEFAULT_SIZE, 572,
												Short.MAX_VALUE)
										.addComponent(pnlSP, javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
						.addContainerGap(28, Short.MAX_VALUE)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(lblQuanLyHoaDon)
						.addGap(18, 18, 18)
						.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
								.addComponent(pnlSP, javax.swing.GroupLayout.Alignment.LEADING,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)
								.addComponent(pnlHoaDon, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(pnlKH, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGap(10, 10, 10)
						.addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
								.addComponent(panelRound21, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(pnlCha, javax.swing.GroupLayout.Alignment.LEADING,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)
								.addComponent(jSPGioHang, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(jSPDanhSachHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 322,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout
						.createSequentialGroup().addContainerGap().addComponent(jPanel2,
								javax.swing.GroupLayout.PREFERRED_SIZE, 1343, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(119, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
						jPanel1Layout.createSequentialGroup().addGap(0, 12, Short.MAX_VALUE).addComponent(jPanel2,
								javax.swing.GroupLayout.PREFERRED_SIZE, 814, javax.swing.GroupLayout.PREFERRED_SIZE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
		this.setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(0, 0, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
	}// </editor-fold>//GEN-END:initComponents

	private void txtSDTKeyTyped(java.awt.event.KeyEvent evt) {// GEN-FIRST:event_txtSDTKeyTyped
		// TODO add your handling code here:
		if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
			String sdt = txtSDT.getText().trim();
			KhachHangDAO dao = new KhachHangDAO();
			KhachHang kh;
			try {
				kh = dao.getKhachHangTheoSDT(sdt);
				if (kh != null) {
					jCbTenKH.setSelectedItem(kh.getTenKH());
					txtDiaChi.setText(kh.getDiaChi());
				} else {
					JOptionPane.showMessageDialog(this, "Không tìm thấy khách hàng với số điện thoại này.");
				}
			} catch (SQLException ex) {
				JOptionPane.showMessageDialog(this, "Lỗi kết nối đến CSDL");
				ex.printStackTrace();
			}
		}
	}// GEN-LAST:event_txtSDTKeyTyped

	private void jCbTenKHActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jCbTenKHActionPerformed
		// TODO add your handling code here:
		String selectedValue = jCbTenKH.getSelectedItem().toString();
		KhachHangDAO dao = new KhachHangDAO();
		try {
			String maKH = dao.getMaKH(selectedValue);
			KhachHang kh = dao.getKhachHangTheoMaKH(maKH);
			txtDiaChi.setText(kh.getDiaChi());
			txtSDT.setText(kh.getsDT());
		} catch (SQLException ex) {
			Logger.getLogger(DatSach.class.getName()).log(Level.SEVERE, null, ex);
		}
	}// GEN-LAST:event_jCbTenKHActionPerformed

	private void btnThemKHActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {// GEN-FIRST:event_btnThemKHActionPerformed
		// TODO add your handling code here:
		ThemKH frm = new ThemKH();
		frm.setVisible(true);
	}// GEN-LAST:event_btnThemKHActionPerformed

	private void txtSoLuongKeyTyped(java.awt.event.KeyEvent evt) throws Exception {// GEN-FIRST:event_txtSoLuongKeyTyped
		// TODO add your handling code here:
		if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
			SanPhamDAO dao = new SanPhamDAO();
			DecimalFormat df = new DecimalFormat("#,### VNĐ");
			String maSP = txtMaSP.getText();
			if (kiemTra()) {
				JOptionPane.showMessageDialog(this, "Mã sản phẩm không được rỗng", "Lỗi", JOptionPane.ERROR_MESSAGE);
				return;
			}

			String donGiaText = txtDonGia.getText();
			if (donGiaText.isEmpty()) {
				JOptionPane.showMessageDialog(this,
						"Giá không được trống, chọn sản phẩm tại bảng 'Danh sách sản phẩm' hoặc tìm sản phẩm để hiện giá.",
						"Lỗi", JOptionPane.ERROR_MESSAGE);
				return;
			}
			double donGia = df.parse(donGiaText).doubleValue();

			int soLuong = Integer.parseInt(txtSoLuong.getText());

			// Kiem tra dieu kien so luong
			int slKho = dao.getSoLuongSanPham(maSP);
			if (slKho < soLuong) {
				JOptionPane.showMessageDialog(this, "Số lượng không đủ. Số lượng hiện có: " + slKho, "Lỗi",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			if (kiemtraMaSPtblGioHang(maSP)) {
				double thanhTien = donGia * soLuong;

				String thanhTienFormatted = df.format(thanhTien);
				txtThanhTien.setText(String.valueOf(thanhTienFormatted));

				SanPham sp = dao.TimKiemSPIsMaSP(maSP);
				BookDTO bookDTO = dao.bookDTOTheoMaSP(maSP);

				tblModel2.addRow(new Object[] { sp.getMaSP(), sp.getTenSP() });
				tblModel2.fireTableDataChanged();

				Object[] newRow = { bookDTO.getMaSP(), bookDTO.getTenSP(), bookDTO.getTenLoaiSach(), bookDTO.getTenTG(),
						bookDTO.getTenNXB(), soLuong, df.format(donGia), thanhTienFormatted };
				tblModel1.addRow(newRow);
				txtMaSP.setText("");
				txtSoLuong.setText("");
				txtDonGia.setText("");
				tblModel1.fireTableDataChanged();

				// Tien hanh cap nhat lai so luong san pham:
				dao.updateGiamSanPham(maSP, soLuong);

				double tongTienTT = thanhTientblDanhSachDat();
				lblTT.setText(String.valueOf(df.format(tongTienTT)));
				showSanPham();

			} else {
				double thanhTien = donGia * soLuong;

				String thanhTienFormatted = df.format(thanhTien);
				txtThanhTien.setText(String.valueOf(thanhTienFormatted));

				for (int i = 0; i < tblDanhSachSPDat.getRowCount(); i++) {
					String maSPtbl = tblDanhSachSPDat.getValueAt(i, 0).toString();
					if (maSP.equals(maSPtbl)) {
						int soLuongTruoc = (int) tblDanhSachSPDat.getValueAt(i, 5);

						String thanhTienStr = tblDanhSachSPDat.getValueAt(i, 7).toString();
						double thanhTienTruoc = df.parse(thanhTienStr).doubleValue();

						// Cap nhat lai so luong va thanh tien
						tblDanhSachSPDat.setValueAt(soLuongTruoc + soLuong, i, 5);
						tblDanhSachSPDat.setValueAt(df.format(thanhTienTruoc + thanhTien), i, 7);

						txtMaSP.setText("");
						txtSoLuong.setText("");
						txtDonGia.setText("");
					}
				}

				double tongTienTT = thanhTientblDanhSachDat();
				lblTT.setText(String.valueOf(df.format(tongTienTT)));

				// Tien hanh cap nhat lai so luong san pham:
				dao.updateGiamSanPham(maSP, soLuong);
				showSanPham();
			}

		}
	}// GEN-LAST:event_txtSoLuongKeyTyped

	private void txtMaSPKeyTyped(java.awt.event.KeyEvent evt) throws SQLException {// GEN-FIRST:event_txtMaSPKeyTyped
		// TODO add your handling code here:
		if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
			StringBuilder sb = new StringBuilder();
			DataValidator.validateEmpty(txtMaSP, sb, "Mã sách không được để trống");
			if (sb.length() > 0) {
				MessageDialogConnectDB.showErrorDialog(giaoDienChinh, sb.toString(), "Lỗi");
				return;
			}
			SanPhamDAO dao = new SanPhamDAO();
			BookDTO bookDTO = dao.bookDTOTheoMaSP(txtMaSP.getText());
			if (bookDTO == null) {
				JOptionPane.showMessageDialog(this, "Không tìm thấy sách", "Thông báo", JOptionPane.ERROR_MESSAGE);
				return;
			}

			DecimalFormat df = new DecimalFormat("#,### VNĐ");
			String dongiaFormatted = df.format(bookDTO.getDonGia());
			txtDonGia.setText(String.valueOf(dongiaFormatted));

			tblModel.setRowCount(0);
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP(), bookDTO.getTenLoaiSach(),
					bookDTO.getTenTG(), bookDTO.getTenNXB() });
			tblModel.fireTableDataChanged();
		}
	}// GEN-LAST:event_txtMaSPKeyTyped

	private void btnThanhToanMouseClicked(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_btnThanhToanMouseClicked
		// TODO add your handling code here:
	}// GEN-LAST:event_btnThanhToanMouseClicked

	private void btnThanhToanActionPerformed(java.awt.event.ActionEvent evt) throws Exception {// GEN-FIRST:event_btnThanhToanActionPerformed
		// TODO add your handling code here:
		String selectedValue = jCbHinhThucThanhToan.getSelectedItem().toString();
		String trangThai;
		if (selectedValue.equals("Hình thức thanh toán")) {
			JOptionPane.showMessageDialog(this, "Vui lòng chọn hình thức thanh toán", "Thông báo",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (selectedValue.equals("Trả sau")) {
			trangThai = "Chưa thanh toán";
		} else {
			String soDu = txtSoDu.getText();
			if (soDu.isEmpty()) {
				JOptionPane.showMessageDialog(this, "Vui lòng nhập số tiền khách trả!", "Thông báo",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			trangThai = "Đã thanh toán";
		}

		if (tblDanhSachSPDat.getRowCount() == 0) {
			JOptionPane.showMessageDialog(this, "Không thể đặt vì không tìm thấy sản phầm muốn đặt!", "Thông báo",
					JOptionPane.ERROR_MESSAGE);
			return;
		} else {
			DatSachDAO daoDS = new DatSachDAO();
			ChiTietDatSachDAO daoCTDS = new ChiTietDatSachDAO();
			maDS = daoDS.generateMaDS();
			KhachHangDAO daoKH = new KhachHangDAO();

			KhachHang kh = daoKH.getKhachHangTheoSDT(txtSDT.getText());

			java.sql.Timestamp gioHienTai = new java.sql.Timestamp(System.currentTimeMillis());
			DecimalFormat df = new DecimalFormat("#,### VNĐ");

			String tTien = lblTT.getText();
			double tt = df.parse(tTien).doubleValue();

			String tienKhachTra = txtTienKhachTra.getText();
			double tienKT = 0;
			double tienKD = 0;

			if (trangThai.equals("Chưa thanh toán")) {
				tienKT = 0;
				tienKD = 0;
			} else {
				tienKT = df.parse(tienKhachTra).doubleValue();
				tienKD = tienKT - tt;
			}

			DatSach ds = new DatSach(maDS, kh, maNV, trangThai, gioHienTai, tt, tienKT, tienKD);
			daoDS.addDatSach(ds);
			for (int i = 0; i < tblDanhSachSPDat.getRowCount(); i++) {
				String maCTDS = daoCTDS.generateMaCTDS();
				String maSP = tblDanhSachSPDat.getValueAt(i, 0).toString();
				SanPham sp = new SanPham();
				sp.setMaSP(maSP);
				int soLuong = (int) tblDanhSachSPDat.getValueAt(i, 5);
				String thanhTienStr = tblDanhSachSPDat.getValueAt(i, 7).toString();
				double thanhTien = df.parse(thanhTienStr).doubleValue();
				ChiTietDatSach chiTietDS = new ChiTietDatSach(maCTDS, ds, sp, soLuong, thanhTien);
				daoCTDS.ThemCTDatSach(chiTietDS);
			}
			tblModel1.setRowCount(0);
			tblModel1.fireTableDataChanged();
			tblModel2.setRowCount(0);
			tblModel2.fireTableDataChanged();
			txtThanhTien.setText("");
			txtTienKhachTra.setText("");
			lblThanhTien.setText("");
			txtSoDu.setText("");

			int result = JOptionPane.showConfirmDialog(null, "Đặt hàng thành công. Bạn có muốn in hóa đơn không?",
					"Thông báo", JOptionPane.YES_NO_OPTION);
			if (result == JOptionPane.YES_OPTION) {
				// Thực hiện in hóa đơn
				TaoHoaDonDS(maDS);
			} else {
				btnInHoaDon.setEnabled(true);
			}

		}
	}// GEN-LAST:event_btnThanhToanActionPerformed

	private void btnInHoaDonActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnInHoaDonActionPerformed
		// TODO add your handling code here:
		TaoHoaDonDS(maDS);
		btnInHoaDon.setEnabled(false);
	}// GEN-LAST:event_btnInHoaDonActionPerformed

	private void btnTimActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {// GEN-FIRST:event_btnTimActionPerformed
		// TODO add your handling code here:
		StringBuilder sb = new StringBuilder();
		DataValidator.validateEmpty(txtMaSP, sb, "Mã sách không được để trống");
		if (sb.length() > 0) {
			MessageDialogConnectDB.showErrorDialog(giaoDienChinh, sb.toString(), "Lỗi");
			return;
		}
		SanPhamDAO dao = new SanPhamDAO();
		BookDTO bookDTO = dao.bookDTOTheoMaSP(txtMaSP.getText());
		if (bookDTO == null) {
			JOptionPane.showMessageDialog(this, "Không tìm thấy sách", "Thông báo", JOptionPane.ERROR_MESSAGE);
			return;
		}

		DecimalFormat df = new DecimalFormat("#,### VNĐ");
		String dongiaFormatted = df.format(bookDTO.getDonGia());
		txtDonGia.setText(String.valueOf(dongiaFormatted));

		tblModel.setRowCount(0);
		tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP(), bookDTO.getTenLoaiSach(),
				bookDTO.getTenTG(), bookDTO.getTenNXB() });
		tblModel.fireTableDataChanged();
	}// GEN-LAST:event_btnTimActionPerformed

	private void jCbNXBActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {// GEN-FIRST:event_jCbNXBActionPerformed
		// TODO add your handling code here:
		String tenNXB = jCbNXB.getSelectedItem().toString();
		String tenTG = jCbTG.getSelectedItem().toString();
		String tenLS = jCbLS.getSelectedItem().toString();

		if (tenNXB.equals("Chọn nhà xuất bản")) {
			JOptionPane.showMessageDialog(this, "Vui lòng chọn nhà xuất bản cần tìm", "Thông báo",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (tenTG.equals("Chọn tác giả") && tenLS.equals("Chọn loại sách")) {
			showTableSanPhamIsTenXNB(tenNXB);
		} else if (tenTG.equals("Chọn tác giả")) {
			showTableSanPhamIsTenLoaiSachAndTenNXB(tenLS, tenNXB);
		} else if (tenLS.equals("Chọn loại sách")) {
			showTableSanPhamIsNXBAndTacGia(tenNXB, tenTG);
		} else {
			showTableSanPhamIsTenLoaiSachAndTenNXBAndTenTG(tenLS, tenNXB, tenTG);
		}
	}// GEN-LAST:event_jCbNXBActionPerformed

	private void jCbTGActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {// GEN-FIRST:event_jCbTGActionPerformed
		// TODO add your handling code here:
		String tenNXB = jCbNXB.getSelectedItem().toString();
		String tenTG = jCbTG.getSelectedItem().toString();
		String tenLS = jCbLS.getSelectedItem().toString();

		if (tenTG.equals("Chọn tác giả")) {
			JOptionPane.showMessageDialog(this, "Vui lòng chọn tác giả cần tìm", "Thông báo",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (tenNXB.equals("Chọn nhà xuất bản") && tenLS.equals("Chọn loại sách")) {
			showTableSanPhamIsTenTacGia(tenTG);
		} else if (tenNXB.equals("Chọn nhà xuất bản")) {
			showTableSanPhamIsTenLoaiSachAndTenTG(tenLS, tenTG);
		} else if (tenLS.equals("Chọn loại sách")) {
			showTableSanPhamIsNXBAndTacGia(tenNXB, tenTG);
		} else {
			showTableSanPhamIsTenLoaiSachAndTenNXBAndTenTG(tenLS, tenNXB, tenTG);
		}
	}// GEN-LAST:event_jCbTGActionPerformed

	private void jCbLSActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {// GEN-FIRST:event_jCbLSActionPerformed
		// TODO add your handling code here:
		String tenNXB = jCbNXB.getSelectedItem().toString();
		String tenTG = jCbTG.getSelectedItem().toString();
		String tenLS = jCbLS.getSelectedItem().toString();

		if (tenLS.equals("Chọn loại sách")) {
			JOptionPane.showMessageDialog(this, "Vui lòng chọn loại sách cần tìm", "Thông báo",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (tenNXB.equals("Chọn nhà xuất bản") && tenTG.equals("Chọn tác giả")) {
			showTableSanPhamIsTenLoaiSach(tenLS);
		} else if (tenNXB.equals("Chọn nhà xuất bản")) {
			showTableSanPhamIsTenLoaiSachAndTenTG(tenLS, tenTG);
		} else if (tenTG.equals("Chọn tác giả")) {
			showTableSanPhamIsTenLoaiSachAndTenNXB(tenLS, tenNXB);
		} else {
			showTableSanPhamIsTenLoaiSachAndTenNXBAndTenTG(tenLS, tenNXB, tenTG);
		}
	}// GEN-LAST:event_jCbLSActionPerformed

	private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) throws SQLException {// GEN-FIRST:event_tblSanPhamMouseClicked
		// TODO add your handling code here:
		int row = tblSanPham.getSelectedRow();
		if (row >= 0) {
			SanPham sp = new SanPham();
			SanPhamDAO dao = new SanPhamDAO();

			String maSP = (String) tblSanPham.getValueAt(row, 0);
//				String tenSP = (String) tblSanPham.getValueAt(row, 1);

			sp = dao.TimKiemSPIsMaSP(maSP);
			txtMaSP.setText(sp.getMaSP());
			DecimalFormat df = new DecimalFormat("#,### VNĐ");
			String dongiaFormatted = df.format(sp.getDonGia());
			txtDonGia.setText(String.valueOf(dongiaFormatted));
			txtSoLuong.requestFocusInWindow();

			txtThanhTien.setText("");
		}
	}// GEN-LAST:event_tblSanPhamMouseClicked

	private void txtTienKhachTraKeyTyped(java.awt.event.KeyEvent evt) throws ParseException {// GEN-FIRST:event_txtTienKhachTraKeyTyped
		// TODO add your handling code here:
		if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
			DecimalFormat df = new DecimalFormat("#,### VNĐ");
			double tienKhachTra = Double.valueOf(txtTienKhachTra.getText());

			String tTien = lblTT.getText();
			double tt = df.parse(tTien).doubleValue();

			if (tienKhachTra < tt) {
				JOptionPane.showMessageDialog(this, "Số tiền khách trả phải lớn hơn tổng tiền", "Thông báo",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			double soDu = tienKhachTra - tt;
			String soDuFormatted = df.format(soDu);

			txtTienKhachTra.setText(df.format(tienKhachTra));
			txtSoDu.setText(soDuFormatted);

		}
	}// GEN-LAST:event_txtTienKhachTraKeyTyped

	private void jCbHinhThucThanhToanActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jCbHinhThucThanhToanActionPerformed
		// TODO add your handling code here:
		String selectedValue = jCbHinhThucThanhToan.getSelectedItem().toString();
		if (selectedValue.equals("Hình thức thanh toán")) {
			JOptionPane.showMessageDialog(this, "Vui lòng chọn hình thức thanh toán", "Thông báo",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (selectedValue.equals("Trả sau")) {
			txtTienKhachTra.setEnabled(false);
		} else {
			txtTienKhachTra.setEnabled(true);
			txtTienKhachTra.requestFocusInWindow();
		}
	}// GEN-LAST:event_jCbHinhThucThanhToanActionPerformed

	private void tblGioHangMouseClicked(java.awt.event.MouseEvent evt) throws Exception {// GEN-FIRST:event_tblGioHangMouseClicked
		// TODO add your handling code here:
		int row = tblGioHang.getSelectedRow();
		if (row >= 0) {
			String maSP = (String) tblGioHang.getValueAt(row, 0);
			// xóa dòng trong bảng giỏ hàng
			tblModel2.removeRow(row);
			// Cap nhat lai so luong san pham trong Database
			int soLuong = getSoLuongtblDanhSachSanPhamMua(maSP);
			SanPhamDAO dao = new SanPhamDAO();
			dao.updateTangSanPham(maSP, soLuong);
			// xóa dòng trong bảng sản phẩm
			xoaSanPhamIsBangDanhSachMuaHang(maSP);
			DecimalFormat df = new DecimalFormat("#,### VNĐ");
			double tongTienTT = thanhTientblDanhSachDat();
			lblTT.setText(String.valueOf(df.format(tongTienTT)));
			showSanPham();
		}
	}// GEN-LAST:event_tblGioHangMouseClicked

	private void showTableSanPhamIsTenXNB(String tenNXB) throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listSachTheoNXB(tenNXB);
		if (tblModel == null) {
			tblModel = new DefaultTableModel();
		}
		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void showTableSanPhamIsTenTacGia(String tenTG) throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listSachTheoTacGia(tenTG);

		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void showTableSanPhamIsTenLoaiSach(String tenLS) throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listSachTheoLoaiSach(tenLS);

		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void showTableSanPhamIsTenLoaiSachAndTenNXB(String tenLS, String tenNXB) throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listSachTheoLoaiSachAndTenNXB(tenLS, tenNXB);

		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void showTableSanPhamIsTenLoaiSachAndTenTG(String tenLS, String tenTG) throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listSachTheoLoaiSachAndTenTacGia(tenLS, tenTG);

		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void showTableSanPhamIsNXBAndTacGia(String tenNXB, String tenTG) throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listSachTheoTenNXBAndTenTacGia(tenNXB, tenTG);

		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void showTableSanPhamIsTenLoaiSachAndTenNXBAndTenTG(String tenLS, String tenNXB, String tenTG)
			throws SQLException {
		SanPhamDAO dao = new SanPhamDAO();
		List<BookDTO> bookDTOs = dao.listDanhSachIsLoaiSachAndTenNachTheXBAndTenTG(tenLS, tenNXB, tenTG);

		tblModel.setRowCount(0);
		for (BookDTO bookDTO : bookDTOs) {
			tblModel.addRow(new Object[] { bookDTO.getMaSP(), bookDTO.getTenSP() });
		}
		tblModel.fireTableDataChanged();
	}

	private void TaoHoaDonDS(String maDS) {
		Connection con = ConnectDB.openConnection();
		try {

			Hashtable<String, Object> map = new Hashtable<String, Object>();
			JasperReport report = JasperCompileManager.compileReport(
					"C:\\Users\\quang\\Documents\\NetBeansProjects\\QuanLyBanSach2\\src\\main\\java\\report\\rptDatSach.jrxml");

			map.put("sMaDS", maDS);

			JasperPrint p = JasperFillManager.fillReport(report, map, con);
			JasperViewer.viewReport(p, false);
			JasperExportManager.exportReportToPdfFile(p, "rptHoaDonDS.pdf");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	private boolean kiemtraMaSPtblGioHang(String maSP) {
		for (int i = 0; i < tblGioHang.getRowCount(); i++) {
			String maSPtbl = tblGioHang.getValueAt(i, 0).toString();
			if (maSP.equals(maSPtbl)) {
				return false;
			}
		}
		return true;
	}

	private double thanhTientblDanhSachDat() throws ParseException {
		DecimalFormat df = new DecimalFormat("#,### VNĐ");
		double tongTien = 0.0;
		for (int i = 0; i < tblDanhSachSPDat.getRowCount(); i++) {
			String thanhTienStr = tblDanhSachSPDat.getValueAt(i, 7).toString();
			double thanhTien = df.parse(thanhTienStr).doubleValue();
			tongTien += thanhTien;
		}
		return tongTien;
	}

	@SuppressWarnings("unused")
	private boolean kiemTra() {
		if (regex.kiemTraRong(txtSoLuong)) {
			return false;
		}
		if (regex.kiemTraSo(txtSoLuong)) {
			return true;
		}
		return false;

	}

	private int getSoLuongtblDanhSachSanPhamMua(String maSP) {
		int soLuong = 0;
		for (int i = 0; i < tblDanhSachSPDat.getRowCount(); i++) {
			String maSPtbl = tblDanhSachSPDat.getValueAt(i, 0).toString();
			if (maSP.equals(maSPtbl)) {
				soLuong = (int) tblDanhSachSPDat.getValueAt(i, 5);
				break;
			}
		}
		return soLuong;
	}

	private void xoaSanPhamIsBangDanhSachMuaHang(String maSP) {
		// xóa dữ liệu trong bảng sản phẩm có mã sản phẩm là maSP
		for (int i = 0; i < tblModel1.getRowCount(); i++) {
			if (tblModel1.getValueAt(i, 0).equals(maSP)) {
				tblModel1.removeRow(i);
				break;
			}
		}
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private com.mycompany.quanlybansach.ui.support.ButtonGradient btnInHoaDon;
	private com.mycompany.quanlybansach.ui.support.ButtonGradient btnThanhToan;
	private com.mycompany.quanlybansach.ui.support.ButtonGradient btnThemKH;
	private com.mycompany.quanlybansach.ui.support.ButtonCustom btnTim;
	private javax.swing.JComboBox<String> jCbHinhThucThanhToan;
	private javax.swing.JComboBox<String> jCbLS;
	private javax.swing.JComboBox<String> jCbNXB;
	private javax.swing.JComboBox<String> jCbTG;
	private javax.swing.JComboBox<String> jCbTenKH;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jSPDanhSachHoaDon;
	private javax.swing.JScrollPane jSPGioHang;
	private javax.swing.JScrollPane jSPSanPham;
	private javax.swing.JLabel lblDiaChi;
	private javax.swing.JLabel lblDonGia;
	private javax.swing.JLabel lblHinhThucThanhToan;
	private javax.swing.JLabel lblLS;
	private javax.swing.JLabel lblMaSP;
	private javax.swing.JLabel lblNXB;
	private javax.swing.JLabel lblQuanLyHoaDon;
	private javax.swing.JLabel lblSDT;
	private javax.swing.JLabel lblSoDu;
	private javax.swing.JLabel lblSoLuong;
	private javax.swing.JLabel lblTG;
	private javax.swing.JLabel lblTT;
	private javax.swing.JLabel lblTenKH;
	private javax.swing.JLabel lblThanhTien;
	private javax.swing.JLabel lblTienKhachTra;
	private javax.swing.JLabel lblTongTien;
	private com.mycompany.quanlybansach.ui.support.PanelRound2 panelRound21;
	private com.mycompany.quanlybansach.ui.support.PanelRound pnlCha;
	private com.mycompany.quanlybansach.ui.support.PanelRound pnlHoaDon;
	private com.mycompany.quanlybansach.ui.support.PanelRound pnlKH;
	private com.mycompany.quanlybansach.ui.support.PanelRound pnlNXB;
	private javax.swing.JPanel pnlSP;
	private javax.swing.JTable tblDanhSachSPDat;
	private javax.swing.JTable tblGioHang;
	private javax.swing.JTable tblSanPham;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtDiaChi;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtDonGia;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtMaSP;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtSDT;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtSoDu;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtSoLuong;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtThanhTien;
	private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtTienKhachTra;
	// End of variables declaration//GEN-END:variables
}

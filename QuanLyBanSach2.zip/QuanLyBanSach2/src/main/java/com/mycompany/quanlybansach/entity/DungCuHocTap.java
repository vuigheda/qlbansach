/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

/**
 *
 * @author quang
 */


public class DungCuHocTap extends SanPham{
	private NhaCungCap maNCC;

	public DungCuHocTap() {
		super();
	}

	public DungCuHocTap(String maSP, String tenSP, String loaiSP, int soLuong, double donGia, NhaCungCap maNCC) {
		super(maSP, tenSP, loaiSP, soLuong, donGia);
		this.maNCC = maNCC;
	}

	public NhaCungCap getMaNCC() {
		return maNCC;
	}

	public void setMaNCC(NhaCungCap maNCC) {
		this.maNCC = maNCC;
	}

	@Override
	public String toString() {
		return "DungCuHocTap [maNCC=" + maNCC + "]";
	}
	
	
}

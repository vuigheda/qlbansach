/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

/**
 *
 * @author quang
 */
import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Regex implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public boolean RegexDiaChi(JTextField txtDiaChi2) {
        String input = txtDiaChi2.getText();
//		String regex = "^([ A-Za-z0-9,.a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]*(\\s?))+$";
        String regex = "[\\w\\s]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai địa chỉ (Ví dụ nhập:56a Cầu Xéo, Tân quí, Tân Phú");
            txtDiaChi2.requestFocus();
            txtDiaChi2.selectAll();
            return true;
        } else {
            return false;
        }
    }
      public boolean RegexTheLoai(JTextField txtDiaChi2) {
        String input = txtDiaChi2.getText();
//		String regex = "^([ A-Za-z0-9,.a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]*(\\s?))+$";
        String regex = "[\\w\\s]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai địa chỉ (Ví dụ nhập:56a Cầu Xéo, Tân quí, Tân Phú");
            txtDiaChi2.requestFocus();
            txtDiaChi2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexTen(JTextField txtTen2) {
        String input = txtTen2.getText();
        String regex = "^([ A-Za-za-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]*(\\s?))+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai tên (Ví dụ nhập:Nguyễn Văn A)");
            txtTen2.requestFocus();
            txtTen2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexTenP(JTextField txtTen2) {
        String input = txtTen2.getText();
        String regex = "^[0-9a-zA-Z]{6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai tên phòng (Ví dụ nhập: NOR456)");
            txtTen2.requestFocus();
            txtTen2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexTenDV(JTextField txtTen2) {
        String input = txtTen2.getText();
        String regex = "^([ A-Za-za-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]*(\\s?))+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai tên (Ví dụ nhập:Rượu nho)");
            txtTen2.requestFocus();
            txtTen2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaNV(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[N][V][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:nv123 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }
     public boolean RegexMaSP(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[S][P][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:SP123 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaTG(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[T][G][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:TG123 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaLS(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[T][L][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:LS123 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaKH(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[K][H][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:nv123 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaDV(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[D][V][0-9]{6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:DV000023 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaNCC(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[N][C][C][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:NCC234 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaNXB(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[N][X][B][0-9]{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:NXB234 )");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean RegexMaP(JTextField txtMa2) {
        String input = txtMa2.getText();
        String regex = "^[a-zA-Z0-9]{4}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai mã (Ví dụ nhập:N001)");
            txtMa2.requestFocus();
            txtMa2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    public boolean kiemTraRong(JTextField txt) {
        if (txt.getText().trim().equals("")) {
            JOptionPane.showMessageDialog(null, "Dữ liệu không được để trống");
            txt.requestFocus();
            return true;
        }
        return false;
    }

    public boolean kiemTraSo(JTextField txtTuoi2) {
        try {
            int x = Integer.parseInt(txtTuoi2.getText());
            if (x < 0) {
                JOptionPane.showMessageDialog(null, "Nhập sai dữ liệu lương (Phải lớn hơn 0)");
                return true;
            }
            return false;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Nhập sai kiểu dữ liệu lương (phải nhập số)");
            return true;
        }
    }

    public boolean RegexSDT(JTextField txtSDT) {
        String input = txtSDT.getText();
        String regex = "^[0][0-9]{9,10}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai số điện thoại (Ví dụ nhập:0987654321)");
            txtSDT.requestFocus();
            txtSDT.selectAll();
            return true;
        } else {
            return false;
        }
    }
//	SỐ LƯỢNG

    public boolean regexSoLuong(JTextField txtSoluong) {
        String input = txtSoluong.getText();
        String regex = "^[1-9][0-9]*$";
        if (!input.matches(regex)) {
            JOptionPane.showMessageDialog(null, "Số lượng phải là số nguyên và lớn hơn 0 (ví dụ nhập: 1000)");
            txtSoluong.requestFocus();
            txtSoluong.selectAll();
            return true;
        }
        return false;

    }

//      TUỔI
    public boolean regexTuoi(JTextField txtTuoi) {
        String input = txtTuoi.getText();
        String regex = "^[0-9]{1,2}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Nhập sai tuổi (Ví dụ nhập: 19 )");
            txtTuoi.requestFocus();
            txtTuoi.selectAll();
            return true;
        } else {
            return false;
        }
    }

//      GIÁ
    public boolean regexGia(JTextField txtGia2) {
        String input = txtGia2.getText();
        String regex = "^[0-9]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Giá phải lớn hơn hoặc bằng 0");
            txtGia2.requestFocus();
            txtGia2.selectAll();
            return true;
        } else {
            return false;
        }
    }
//      SỨC CHỨA         

    public boolean regexSucchua(JTextField txtSucchua2) {
        String input = txtSucchua2.getText();
        String regex = "^[1-9][0-9]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Sức chứa phải lớn hơn 0");
            txtSucchua2.requestFocus();
            txtSucchua2.selectAll();
            return true;
        } else {
            return false;
        }
    }

    // số lượng người
    public boolean regexSoLuongNguoi(JTextField txtSucchua2) {
        String input = txtSucchua2.getText();
        String regex = "^[1-9][0-9]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        if (!matcher.find()) {
            JOptionPane.showMessageDialog(null, "Chỉ được nhập số người lớn hơn 0");
            txtSucchua2.requestFocus();
            txtSucchua2.selectAll();
            return true;
        } else {
            return false;
        }
    }

}

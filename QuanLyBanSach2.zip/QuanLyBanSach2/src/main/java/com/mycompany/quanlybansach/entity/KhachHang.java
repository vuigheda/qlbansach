/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

import java.util.Objects;

/**
 *
 * @author quang
 */

public class KhachHang {
	private String maKH;
	private String tenKH;
	private String diaChi;
	private int GioiTinh;
	private String sDT;

	public KhachHang() {
		super();
	}

	public KhachHang(String maKH, String tenKH, String diaChi, int gioiTinh, String sDT) {
		super();
		this.maKH = maKH;
		this.tenKH = tenKH;
		this.diaChi = diaChi;
		GioiTinh = gioiTinh;
		this.sDT = sDT;
	}

	public String getMaKH() {
		return maKH;
	}

	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}

	public String getTenKH() {
		return tenKH;
	}

	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public int getGioiTinh() {
		return GioiTinh;
	}

	public void setGioiTinh(int gioiTinh) {
		GioiTinh = gioiTinh;
	}

	public String getsDT() {
		return sDT;
	}

	public void setsDT(String sDT) {
		this.sDT = sDT;
	}

	@Override
	public int hashCode() {
		return Objects.hash(GioiTinh, diaChi, maKH, sDT, tenKH);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		KhachHang other = (KhachHang) obj;
		return GioiTinh == other.GioiTinh && Objects.equals(diaChi, other.diaChi) && Objects.equals(maKH, other.maKH)
				&& Objects.equals(sDT, other.sDT) && Objects.equals(tenKH, other.tenKH);
	}

	@Override
	public String toString() {
		return "KhachHang [maKH=" + maKH + ", tenKH=" + tenKH + ", diaChi=" + diaChi + ", GioiTinh=" + GioiTinh
				+ ", sDT=" + sDT + "]";
	}

}

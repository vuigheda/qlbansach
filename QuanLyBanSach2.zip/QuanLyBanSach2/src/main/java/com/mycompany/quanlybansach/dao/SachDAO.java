package com.mycompany.quanlybansach.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.Sach;

public class SachDAO {
	private Connection con;

	public SachDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	public boolean insert(Sach sach) throws SQLException {
		String sql = "INSERT INTO [dbo].[Sach]\r\n" + "           ([MaSP]\r\n" + "           ,[MaTG]\r\n"
				+ "           ,[MaNXB]\r\n" + "           ,[MaLoaiSach])\r\n" + "     VALUES\r\n"
				+ "           (?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, sach.getMaSP());
		stmt.setString(2, sach.getMaTG().getMaTacGia());
		stmt.setString(3, sach.getMaNXB().getMaNXB());
		stmt.setString(4, sach.getMaLoaiSach().getMaLoaiSach());

		return stmt.executeUpdate() > 0;
	}

	public boolean delete(String maSP) throws SQLException {
		String sql = "DELETE FROM [dbo].[Sach]\r\n" + "      WHERE  MaSP = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maSP);
		return stmt.executeLargeUpdate() > 0;
	}

	public boolean update(Sach sach) throws SQLException {
		String sql = "UPDATE [dbo].[Sach]\r\n"
				+ "   SET [MaSP] = ?\r\n"
				+ "      ,[MaTG] = ?\r\n"
				+ "      ,[MaNXB] = ?\r\n"
				+ "      ,[MaLoaiSach] = ?\r\n"
				+ " WHERE MaSP = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, sach.getMaSP());
		stmt.setString(2, sach.getMaTG().getMaTacGia());
		stmt.setString(3, sach.getMaNXB().getMaNXB());
		stmt.setString(4, sach.getMaLoaiSach().getMaLoaiSach());
		stmt.setString(5, sach.getMaSP());

		return stmt.executeUpdate() > 0;
	}

	public SachDTO getSach(String maSP) throws SQLException {
	    SachDTO sach = null;

	    String query = "SELECT s.[MaSP], tg.[TenTG], ls.[TenLoaiSach], nxb.[TenNXB] FROM [dbo].[Sach] s " +
	                   "INNER JOIN [dbo].[TacGia] tg ON s.MaTG = tg.MaTG " +
	                   "INNER JOIN [dbo].[LoaiSach] ls ON s.MaLoaiSach = ls.MaLoaiSach " +
	                   "INNER JOIN [dbo].[NhaXuatBan] nxb ON s.MaNXB = nxb.MaNXB " +
	                   "WHERE MaSP = ?";
	    PreparedStatement ps = con.prepareStatement(query);
	    ps.setString(1, maSP);
	    ResultSet rs = ps.executeQuery();

	    if (rs.next()) {
	        String maSPResult = rs.getString("MaSP");
	        String tenTG = rs.getString("TenTG");
	        String tenTheLoai = rs.getString("TenLoaiSach");
	        String tenNXB = rs.getString("TenNXB");

	        sach = new SachDTO(maSPResult, tenTG, tenTheLoai, tenNXB);
	    }

	    return sach;
	}


	public class SachDTO {
		private String maSP;
		private String tenTG;
		private String tenTheLoai;
		private String tenNXB;
		
		
		public SachDTO() {
			super();
		}

		public SachDTO(String maSP, String tenTG, String tenTheLoai, String tenNXB) {
			this.maSP = maSP;
			this.tenTG = tenTG;
			this.tenTheLoai = tenTheLoai;
			this.tenNXB = tenNXB;
		}

		public String getMaSP() {
			return maSP;
		}

		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}

		public String getTenTG() {
			return tenTG;
		}

		public void setTenTG(String tenTG) {
			this.tenTG = tenTG;
		}

		public String getTenTheLoai() {
			return tenTheLoai;
		}

		public void setTenTheLoai(String tenTheLoai) {
			this.tenTheLoai = tenTheLoai;
		}

		public String getTenNXB() {
			return tenNXB;
		}

		public void setTenNXB(String tenNXB) {
			this.tenNXB = tenNXB;
		}
	}

}

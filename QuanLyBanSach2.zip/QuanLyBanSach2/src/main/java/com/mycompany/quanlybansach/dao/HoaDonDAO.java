/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.HoaDon;
import com.mycompany.quanlybansach.entity.KhachHang;
import com.mycompany.quanlybansach.entity.NhanVien;

/**
 *
 * @author quang
 */
public class HoaDonDAO {

	private Connection con;

	public HoaDonDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	public boolean ThemHoaDon(HoaDon hd) {

		try {
			String sql = "INSERT INTO [dbo].[HoaDon]\r\n" + "           ([MaHD]\r\n" + "           ,[MaKH]\r\n"
					+ "           ,[MaNV]\r\n" + "           ,[NgayLapHoaDon]\r\n" + "           ,[TongTien]\r\n"
					+ "           ,[TienKhachTra]\r\n" + "           ,[TienKhachDu])\r\n" + "     VALUES\r\n"
					+ "           (?,?,?,?,?,?,?)";

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, hd.getMaHD());
			stmt.setString(2, hd.getMaKH().getMaKH());
			stmt.setString(3, hd.getMaNV().getMaNV());
			stmt.setTimestamp(4, hd.getNgayLapHoaDon());
			stmt.setDouble(5, hd.getTongTien());
			stmt.setDouble(6, hd.getTienKhachTra());
			stmt.setDouble(7, hd.getTienKhacDu());

			int n = stmt.executeUpdate();

			return n > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	public boolean update(HoaDon hd) throws SQLException {

		String sql = "UPDATE [dbo].[HoaDon]\r\n" + "   SET [MaHD] = ?\r\n" + "      ,[MaKH] = ?\r\n"
				+ "      ,[MaNV] = ?\r\n" + "      ,[NgayLapHoaDon] = ?\r\n" + "      ,[TongTien] = ?\r\n"
				+ "      ,[TienKhachTra] = ?\r\n" + "      ,[TienKhachDu] = ?\r\n" + " WHERE MaHD = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, hd.getMaHD());
		stmt.setString(2, hd.getMaKH().getMaKH());
		stmt.setString(3, hd.getMaNV().getMaNV());
		stmt.setTimestamp(4, hd.getNgayLapHoaDon());
		stmt.setDouble(5, hd.getTongTien());
		stmt.setDouble(6, hd.getTienKhachTra());
		stmt.setDouble(7, hd.getTienKhacDu());
		stmt.setInt(8, hd.getMaHD());

		return stmt.executeUpdate() > 0;
	}

	public boolean deleteMaHD(int maHD) throws SQLException {

		String sql = "\r\n" + "DELETE FROM [dbo].[HoaDon]\r\n" + "      WHERE MaHD = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, maHD);

		return stmt.executeLargeUpdate() > 0;

	}

	public List<HoaDon> LoadHoaDon() throws SQLException {
		String sql = "SELECT * FROM [dbo].[HoaDon]";
		List<HoaDon> dsHD = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			HoaDon hd = new HoaDon();
			KhachHang kh = new KhachHang();
			NhanVien nv = new NhanVien();

			hd.setMaHD(rs.getInt("MaHD"));
			kh.setMaKH(rs.getString("MaKH"));
			nv.setMaNV(rs.getString("MaNV"));
			hd.setMaKH(kh);
			hd.setMaNV(nv);
			hd.setNgayLapHoaDon(rs.getTimestamp("NgayLapHoaDon"));
			hd.setTongTien(rs.getDouble("TongTien"));
			hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
			hd.setTienKhacDu(rs.getDouble("TienKhachDu"));
			dsHD.add(hd);
		}

		return dsHD;
	}

	public HoaDon getHoaDonTheoMaHD(int maHD) throws SQLException {
		String sql = "SELECT * FROM [dbo].[HoaDon] WHERE MaHD = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, maHD);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			HoaDon hd = new HoaDon();
			KhachHang kh = new KhachHang();
			NhanVien nv = new NhanVien();

			hd.setMaHD(rs.getInt("MaHD"));
			kh.setMaKH(rs.getString("MaKH"));
			nv.setMaNV(rs.getString("MaNV"));
			hd.setMaKH(kh);
			hd.setMaNV(nv);
			hd.setNgayLapHoaDon(rs.getTimestamp("NgayLapHoaDon"));
			hd.setTongTien(rs.getDouble("TongTien"));
			hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
			hd.setTienKhacDu(rs.getDouble("TienKhachDu"));

			return hd;
		}

		return null;
	}

	public List<HoaDon> getHoaDonTheoMaKH(String maKH) throws SQLException {
		String sql = "SELECT * FROM [dbo].[HoaDon] WHERE MaKH = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maKH);
		ResultSet rs = stmt.executeQuery();
		List<HoaDon> hoaDons = new ArrayList<>();
		while (rs.next()) {
			HoaDon hd = new HoaDon();
			KhachHang kh = new KhachHang();
			NhanVien nv = new NhanVien();
			hd.setMaHD(rs.getInt("MaHD"));
			kh.setMaKH(rs.getString("MaKH"));
			nv.setMaNV(rs.getString("MaNV"));
			hd.setMaKH(kh);
			hd.setMaNV(nv);
			hd.setNgayLapHoaDon(rs.getTimestamp("NgayLapHoaDon"));
			hd.setTongTien(rs.getDouble("TongTien"));
			hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
			hd.setTienKhacDu(rs.getDouble("TienKhachDu"));
			hoaDons.add(hd);
		}
		return hoaDons;
	}

	public int generateProductId() throws SQLException {
		int MaHD = 10000;
		String sql = "SELECT MAX(MaHD) FROM HoaDon";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);

		rs.next();
		int maxMaHD = rs.getInt(1);

		if (maxMaHD >= MaHD) {
			MaHD = maxMaHD + 1;
		}

		return MaHD;
	}

	public HoaDonDTO getHoaDonDTOIsMaDS(int maHD) throws SQLException {
		String sql = "SELECT    dbo.HoaDon.MaHD, dbo.KhachHang.TenKH, dbo.NhanVien.TenNV, dbo.HoaDon.NgayLapHoaDon, dbo.HoaDon.TongTien, dbo.HoaDon.TienKhachTra, dbo.HoaDon.TienKhachDu\r\n"
				+ "FROM         dbo.HoaDon INNER JOIN\r\n"
				+ "                      dbo.KhachHang ON dbo.HoaDon.MaKH = dbo.KhachHang.MaKH INNER JOIN\r\n"
				+ "                      dbo.NhanVien ON dbo.HoaDon.MaNV = dbo.NhanVien.MaNV\r\n"
				+ "WHERE dbo.HoaDon.MaHD = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, maHD);
		ResultSet rs = stmt.executeQuery();
		HoaDonDTO hd = new HoaDonDTO();
		if (rs.next()) {
			hd.setMaHD(rs.getInt("MaHD"));
			hd.setTenKH(rs.getString("TenKH"));
			hd.setTenNV(rs.getString("TenNV"));
			hd.setNgayLapHoaDon(rs.getTimestamp("NgayLapHoaDon"));
			hd.setTongTien(rs.getDouble("TongTien"));
			hd.setTienKhachTra(rs.getDouble("TienKhachTra"));
			hd.setTienKhacDu(rs.getDouble("TienKhachDu"));
		}
		return hd;
	}

	public class HoaDonDTO {
		private int maHD;
		private String tenKH;
		private String tenNV;
		private Timestamp ngayLapHoaDon;
		private double tongTien;
		private double tienKhachTra;
		private double tienKhacDu;

		public HoaDonDTO() {
			super();
		}

		public HoaDonDTO(int maHD, String tenKH, String tenNV, Timestamp ngayLapHoaDon, double tongTien,
				double tienKhachTra, double tienKhacDu) {
			super();
			this.maHD = maHD;
			this.tenKH = tenKH;
			this.tenNV = tenNV;
			this.ngayLapHoaDon = ngayLapHoaDon;
			this.tongTien = tongTien;
			this.tienKhachTra = tienKhachTra;
			this.tienKhacDu = tienKhacDu;
		}

		public int getMaHD() {
			return maHD;
		}

		public void setMaHD(int maHD) {
			this.maHD = maHD;
		}

		public String getTenKH() {
			return tenKH;
		}

		public void setTenKH(String tenKH) {
			this.tenKH = tenKH;
		}

		public String getTenNV() {
			return tenNV;
		}

		public void setTenNV(String tenNV) {
			this.tenNV = tenNV;
		}

		public Timestamp getNgayLapHoaDon() {
			return ngayLapHoaDon;
		}

		public void setNgayLapHoaDon(Timestamp ngayLapHoaDon) {
			this.ngayLapHoaDon = ngayLapHoaDon;
		}

		public double getTongTien() {
			return tongTien;
		}

		public void setTongTien(double tongTien) {
			this.tongTien = tongTien;
		}

		public double getTienKhachTra() {
			return tienKhachTra;
		}

		public void setTienKhachTra(double tienKhachTra) {
			this.tienKhachTra = tienKhachTra;
		}

		public double getTienKhacDu() {
			return tienKhacDu;
		}

		public void setTienKhacDu(double tienKhacDu) {
			this.tienKhacDu = tienKhacDu;
		}

		@Override
		public String toString() {
			return "HoaDonDTO [maHD=" + maHD + ", tenKH=" + tenKH + ", tenNV=" + tenNV + ", ngayLapHoaDon="
					+ ngayLapHoaDon + ", tongTien=" + tongTien + ", tienKhachTra=" + tienKhachTra + ", tienKhacDu="
					+ tienKhacDu + "]";
		}

	}
}


package com.mycompany.quanlybansach.ui;


import com.mycompany.quanlybansach.dao.NhanVienDao;
import com.mycompany.quanlybansach.dao.ThongKeDAO;
import com.mycompany.quanlybansach.entity.HoaDon;
import com.mycompany.quanlybansach.entity.NhanVien;
import com.mycompany.quanlybansach.ui.support.TableCustom;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ThongKeDoanhThu extends javax.swing.JPanel {
    @SuppressWarnings("unchecked")
    private DefaultTableModel tblModel;
    private GiaoDienChinh giaoDienChinh;

    public ThongKeDoanhThu() {
        initComponents();
    }


    private void initComponents() {

        pnlThemTG = new com.mycompany.quanlybansach.ui.support.PanelRound();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblTotalProductSell = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblDoanhThu = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblThongKeDoanhThu = new javax.swing.JTable();
        pnlThemTG1 = new com.mycompany.quanlybansach.ui.support.PanelRound();
        lblTenNXBThem1 = new javax.swing.JLabel();
        lblMaNXBThem1 = new javax.swing.JLabel();
        lbldiachiNXBThem1 = new javax.swing.JLabel();
        txtdiachiNXBThem1 = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
        jDateBegin = new com.toedter.calendar.JDateChooser();
        jDateEnd = new com.toedter.calendar.JDateChooser();
        btnXemHoaDon = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
        btnInHoaDon = new com.mycompany.quanlybansach.ui.support.ButtonCustom();

        setBackground(new java.awt.Color(99, 183, 183));

        pnlThemTG.setBackground(new java.awt.Color(255, 255, 255));
        pnlThemTG.setRoundBottomLeft(50);
        pnlThemTG.setRoundBottomRight(50);
        pnlThemTG.setRoundTopLeft(50);
        pnlThemTG.setRoundTopRight(50);

        jLabel2.setBackground(new java.awt.Color(99, 183, 183));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Tổng doanh thu");

        jTextField1.setBackground(new java.awt.Color(255, 0, 0));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(99, 183, 183));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Số lượng hóa đơn bán được: ");

        lblTotalProductSell.setText("...");

        jLabel5.setBackground(new java.awt.Color(99, 183, 183));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Doanh thu:");

        lblDoanhThu.setText("...");

        javax.swing.GroupLayout pnlThemTGLayout = new javax.swing.GroupLayout(pnlThemTG);
        pnlThemTG.setLayout(pnlThemTGLayout);
        pnlThemTGLayout.setHorizontalGroup(
                pnlThemTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnlThemTGLayout.createSequentialGroup()
                                .addGroup(pnlThemTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThemTGLayout.createSequentialGroup()
                                                .addContainerGap()
                                                .addComponent(jTextField1))
                                        .addGroup(pnlThemTGLayout.createSequentialGroup()
                                                .addGap(113, 113, 113)
                                                .addComponent(jLabel2)
                                                .addGap(0, 97, Short.MAX_VALUE)))
                                .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThemTGLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblDoanhThu, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(24, 24, 24))
                        .addGroup(pnlThemTGLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblTotalProductSell, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlThemTGLayout.setVerticalGroup(
                pnlThemTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnlThemTGLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addGroup(pnlThemTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel3)
                                        .addComponent(lblTotalProductSell))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                                .addGroup(pnlThemTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel5)
                                        .addComponent(lblDoanhThu))
                                .addGap(20, 20, 20))
        );

        jLabel1.setBackground(new java.awt.Color(99, 183, 183));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("THỐNG KÊ DOANH THU");

        tblThongKeDoanhThu.setModel(tblModel = new javax.swing.table.DefaultTableModel(
                new Object[][]{

                }
                ,
                new String[]{
                        "Mã hóa đơn", "Mã khách hàng", "Mã nhân viên", "Ngày tạo", "Tổng thành tiền"
                }
        ));
        jScrollPane1.setViewportView(tblThongKeDoanhThu);
        TableCustom.apply(jScrollPane1, TableCustom.TableType.DEFAULT);
        jScrollPane1.getVerticalScrollBar().setUnitIncrement(20);

        pnlThemTG1.setBackground(new java.awt.Color(255, 255, 255));
        pnlThemTG1.setRoundBottomLeft(50);
        pnlThemTG1.setRoundBottomRight(50);
        pnlThemTG1.setRoundTopLeft(50);
        pnlThemTG1.setRoundTopRight(50);

        lblTenNXBThem1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblTenNXBThem1.setText("Đến ngày:");

        lblMaNXBThem1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblMaNXBThem1.setText("Từ ngày:");

        lbldiachiNXBThem1.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbldiachiNXBThem1.setText("Địa Chỉ");

        btnXemHoaDon.setText("Xem hóa đơn");
        btnXemHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXemHoaDonActionPerformed(evt);
            }
        });

        btnInHoaDon.setText("Xuất Excel");
        btnInHoaDon.setEnabled(false);
        btnInHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInHoaDonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlThemTG1Layout = new javax.swing.GroupLayout(pnlThemTG1);
        pnlThemTG1.setLayout(pnlThemTG1Layout);
        pnlThemTG1Layout.setHorizontalGroup(
                pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnlThemTG1Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(lbldiachiNXBThem1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(46, 46, 46)
                                .addComponent(txtdiachiNXBThem1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(pnlThemTG1Layout.createSequentialGroup()
                                .addGroup(pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(pnlThemTG1Layout.createSequentialGroup()
                                                .addGap(174, 174, 174)
                                                .addComponent(lblMaNXBThem1))
                                        .addGroup(pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlThemTG1Layout.createSequentialGroup()
                                                        .addGap(129, 129, 129)
                                                        .addGroup(pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(jDateEnd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(jDateBegin, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlThemTG1Layout.createSequentialGroup()
                                                        .addGap(160, 160, 160)
                                                        .addComponent(lblTenNXBThem1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(pnlThemTG1Layout.createSequentialGroup()
                                .addContainerGap(94, Short.MAX_VALUE)
                                .addComponent(btnXemHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(65, 65, 65)
                                .addComponent(btnInHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51))
        );
        pnlThemTG1Layout.setVerticalGroup(
                pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThemTG1Layout.createSequentialGroup()
                                .addComponent(lblMaNXBThem1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jDateBegin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTenNXBThem1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jDateEnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnXemHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnInHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(85, 85, 85)
                                .addGroup(pnlThemTG1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lbldiachiNXBThem1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtdiachiNXBThem1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(pnlThemTG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(30, 30, 30)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(17, 17, 17))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(355, 355, 355))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(pnlThemTG1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(613, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(315, 315, 315)
                                                .addComponent(pnlThemTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(28, 28, 28)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(15, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(79, 79, 79)
                                        .addComponent(pnlThemTG1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(198, Short.MAX_VALUE)))
        );
    }

    private void btnXemHoaDonActionPerformed(java.awt.event.ActionEvent evt) {
        Date selectedBeginDate = jDateBegin.getDate();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String dateBeginString = formatter.format(selectedBeginDate);

        Date selectedEndDate = jDateEnd.getDate();
        SimpleDateFormat formatterEnd = new SimpleDateFormat("yyyy-MM-dd");
        String dateEndString = formatterEnd.format(selectedEndDate);


        if (dateBeginString != null && dateEndString != null) {

            ThongKeDAO dao = new ThongKeDAO();
            tblModel.setRowCount(0);
            try {
                List<HoaDon> lstHd = dao.showThongKeDoanhThu(dateBeginString, dateEndString);

                double tongtien = 0;
                if (lstHd.size() == 0) {
                    JOptionPane.showMessageDialog(giaoDienChinh, "Không có hóa đơn nào trong khoảng thời gian đã chọn!", "Nhập sai thời gian", JOptionPane.WARNING_MESSAGE);
                } else {
                    btnInHoaDon.setEnabled(true);
                    DecimalFormat df = new DecimalFormat("#,### VNĐ");
                    String tongTien = "";
                    for (HoaDon it : lstHd) {
                        tongtien += it.getTongTien();
                        String dongiaFormatted = df.format(it.getTongTien());
                        tongTien = String.valueOf(dongiaFormatted);
                        Object[] row = {it.getMaHD(), it.getMaKH().getMaKH(), it.getMaNV().getMaNV(), it.getNgayLapHoaDon(), tongTien};
                        tblModel.addRow(row);
                    }

                    lblTotalProductSell.setText(lstHd.size() + "");
                    lblDoanhThu.setText(df.format(tongtien));
                }


            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

    }

    private void btnInHoaDonActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
        Workbook workbook = new XSSFWorkbook();
        // Tạo trang mới trong workbook
        Sheet sheet = workbook.createSheet("Danh sách Sách");

        // Lấy dữ liệu từ bảng vào list
        List<String[]> data = new ArrayList<>();
        int rowCount = tblThongKeDoanhThu.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String[] row = new String[5];
            for (int j = 0; j < 5; j++) {
                row[j] = String.valueOf(tblThongKeDoanhThu.getValueAt(i, j));
            }
            data.add(row);
        }

        // Khởi tạo header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Mã Hóa Đơn");
        headerRow.createCell(1).setCellValue("Mã Khách Hàng");
        headerRow.createCell(2).setCellValue("Mã Nhân Viên");
        headerRow.createCell(3).setCellValue("Ngày Tạo");
        headerRow.createCell(4).setCellValue("Tổng Thành Tiền");


        // Thêm dữ liệu từ list vào các row
        int rowNum = 1;
        for (String[] row : data) {
            Row dataRow = sheet.createRow(rowNum++);
            dataRow.createCell(0).setCellValue(row[0]);
            dataRow.createCell(1).setCellValue(row[1]);
            dataRow.createCell(2).setCellValue(row[2]);
            dataRow.createCell(3).setCellValue(row[3]);
            dataRow.createCell(4).setCellValue(row[4]);
        }

        // Lưu file excel
        try {
            FileOutputStream outputStream = new FileOutputStream("Danh_sach_sach_doanh_thu.xlsx");
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
            // Mở file excel
            File file = new File("Danh_sach_sach_doanh_thu.xlsx");
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(file);
            }
            JOptionPane.showMessageDialog(this, "Xuất file excel thành công!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi xuất file excel: " + ex.getMessage());
        }
    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }


    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnInHoaDon;
    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnXemHoaDon;
    private com.toedter.calendar.JDateChooser jDateBegin;
    private com.toedter.calendar.JDateChooser jDateEnd;
    private javax.swing.JLabel lblDoanhThu;
    private javax.swing.JTable tblThongKeDoanhThu;


    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;

    private javax.swing.JLabel lblMaNXBThem1;
    private javax.swing.JLabel lblTenNXBThem1;
    private javax.swing.JLabel lblTotalProductSell;
    private javax.swing.JLabel lbldiachiNXBThem1;
    private com.mycompany.quanlybansach.ui.support.PanelRound pnlThemTG;
    private com.mycompany.quanlybansach.ui.support.PanelRound pnlThemTG1;
    private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtdiachiNXBThem1;
    // End of variables declaration                   
}

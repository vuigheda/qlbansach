/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.NhanVien;

public class NhanVienDao {

    private Connection con;

    public NhanVienDao() {
        con = ConnectDB.getInstance().getConnection();
    }

// Them nhan vien
    public boolean insert(NhanVien nv) throws SQLException {
        String sql = "INSERT INTO [dbo].[NhanVien]\n"
                + "           ([MaNV]\n"
                + "           ,[TenNV]\n"
                + "           ,[SDT]\n"
                + "           ,[ChucVu]\n"
                + "           ,[DiaChi]\n"
                + "           ,[Tuoi]\n"
                + "           ,[GioiTinh]\n"
                + "           ,[TaiKhoan])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?,?,?,?)";

        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, nv.getMaNV());
        stmt.setString(2, nv.getTenNV());
        stmt.setString(3, nv.getsDT());
        stmt.setInt(4, nv.getChucVu());
        stmt.setString(5, nv.getDiaChi());
        stmt.setInt(6, nv.getTuoi());
        stmt.setInt(7, nv.getGioiTinh());
        stmt.setString(8, nv.getTaiKhoan().getTaiKhoan());
        return stmt.executeUpdate() > 0;
    }

    // Update nhan vien
    public boolean update(NhanVien nv) throws SQLException {

        String sql = "UPDATE [dbo].[NhanVien]" + " SET TenNV = ?,SDT = ?,ChucVu = ?,DiaChi = ?,Tuoi = ?,GioiTinh = ?,TaiKhoan = ?" + " WHERE MaNV = ?";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(8, nv.getMaNV());
        pstmt.setString(1, nv.getTenNV());
        pstmt.setString(2, nv.getsDT());
        pstmt.setInt(3, nv.getChucVu());
        pstmt.setString(4, nv.getDiaChi());
        pstmt.setInt(5, nv.getTuoi());
        pstmt.setInt(6, nv.getGioiTinh());
        pstmt.setString(7, nv.getMaNV());

        return pstmt.executeUpdate() > 0;

    }
    // Xoa nhan vien bang maKH

    public boolean deleteMaNV(String maNV) throws SQLException {

        String sql = "DELETE FROM [dbo].[NhanVien]\r\n" + "		WHERE MaNV = ? ";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maNV);

        return stmt.executeLargeUpdate() > 0;

    }

    // Xoa nhan vien bang SDT
    public boolean deleteSDT(String sDT) throws SQLException {

        String sql = "DELETE FROM [dbo].[NhanVien]\r\n" + "		WHERE SDT = ? ";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, sDT);

        return stmt.executeLargeUpdate() > 0;

    }

// Tim kiem nhan vien theo ma nhan vien
    public NhanVien TimKiemNVIsMaNV(String maNV) throws SQLException {
        String sql = "SELECT * FROM NhanVien WHERE MaNV = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maNV);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setMaNV(rs.getString("MaNV"));
            nv.setTenNV(rs.getString("TenNV"));
            nv.setGioiTinh(rs.getInt("GioiTinh"));
            nv.setTuoi(rs.getInt("Tuoi"));
            nv.setDiaChi(rs.getString("DiaChi"));
            nv.setsDT(rs.getString("SDT"));
            nv.setChucVu(rs.getInt("ChucVu"));
            return nv;
        }
        return null;
    }
    
    public NhanVien TimKiemNVIsTenNV(String TenNV) throws SQLException {
        String sql = "SELECT * FROM NhanVien WHERE TenNV LIKE N'%' + ? + '%'";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, TenNV);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setMaNV(rs.getString("MaNV"));
            nv.setTenNV(rs.getString("TenNV"));
            nv.setGioiTinh(rs.getInt("GioiTinh"));
            nv.setTuoi(rs.getInt("Tuoi"));
            nv.setDiaChi(rs.getString("DiaChi"));
            nv.setsDT(rs.getString("SDT"));
            nv.setChucVu(rs.getInt("ChucVu"));
            return nv;
        }
        return null;
    }
    
    public NhanVien TimKiemNVIsSDT(String sDT) throws SQLException {
        String sql = "SELECT * FROM NhanVien WHERE SDT = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, sDT);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setMaNV(rs.getString("MaNV"));
            nv.setTenNV(rs.getString("TenNV"));
            nv.setGioiTinh(rs.getInt("GioiTinh"));
            nv.setTuoi(rs.getInt("Tuoi"));
            nv.setDiaChi(rs.getString("DiaChi"));
            nv.setsDT(rs.getString("SDT"));
            nv.setChucVu(rs.getInt("ChucVu"));
            return nv;
        }
        return null;
    }

    // Hien thi danh sach nhan vien
    public List<NhanVien> DanhSachNhanVien() throws SQLException {
        String sql = "SELECT * FROM [dbo].[NhanVien]";
        List<NhanVien> dsNV = new ArrayList<>();
        PreparedStatement stmt = con.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setMaNV(rs.getString("MaNV"));
            nv.setTenNV(rs.getString("TenNV"));
            nv.setGioiTinh(rs.getInt("GioiTinh"));
            nv.setTuoi(rs.getInt("Tuoi"));
            nv.setDiaChi(rs.getString("DiaChi"));
            nv.setsDT(rs.getString("SDT"));
            nv.setChucVu(rs.getInt("ChucVu"));

            dsNV.add(nv);
        }

        return dsNV;

    }
}

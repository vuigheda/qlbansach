/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

/**
 *
 * @author quang
 */


public class TacGia {
	private String maTacGia;
	private String tenTacGia;
	private String quocTich;

	public TacGia() {
		super();
	}

	public TacGia(String maTacGia, String tenTacGia, String quocTich) {
		super();
		this.maTacGia = maTacGia;
		this.tenTacGia = tenTacGia;
		this.quocTich = quocTich;
	}

	public String getMaTacGia() {
		return maTacGia;
	}

	public void setMaTacGia(String maTacGia) {
		this.maTacGia = maTacGia;
	}

	public String getTenTacGia() {
		return tenTacGia;
	}

	public void setTenTacGia(String tenTacGia) {
		this.tenTacGia = tenTacGia;
	}

	public String getQuocTich() {
		return quocTich;
	}

	public void setQuocTich(String quocTich) {
		this.quocTich = quocTich;
	}

	@Override
	public String toString() {
		return "TacGia [maTacGia=" + maTacGia + ", tenTacGia=" + tenTacGia + ", quocTich=" + quocTich + "]";
	}

}


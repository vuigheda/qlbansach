/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.connectDB;

/**
 *
 * @author quang
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {

	private static ConnectDB instance;

	public static Connection openConnection() {
		try {
			String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyNhaSach;trustServerCertificate=true;";
			String us = "sa";
			String pw = "sapassword";
			return DriverManager.getConnection(url, us, pw);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	private Connection con;

	private ConnectDB() {

		try {
			String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyNhaSach;trustServerCertificate=true;";
			String us = "sa";
			String pw = "sapassword";
			con = DriverManager.getConnection(url, us, pw);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public synchronized static ConnectDB getInstance() {
		if (instance == null) {
			instance = new ConnectDB();
		}
		return instance;
	}

	public Connection getConnection() {
		return con;
	}
}

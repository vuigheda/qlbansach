/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */
import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.NhaCungCap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class NhaCungCapDAO {

    private Connection con;

    public NhaCungCapDAO() {
        con = ConnectDB.getInstance().getConnection();
    }

    // Them NCC
    public boolean insert(NhaCungCap ncc) throws SQLException {
        String sql = "INSERT INTO [dbo].[NhaCungCap]\r\n" + "           ([MaNCC]\r\n" + "           ,[TenNCC]\r\n"
                + "           ,[DiaChi]\r\n" + "           ,[SDT])\r\n" + "     VALUES\r\n" + "           (?,?,?,?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, ncc.getMaNCC());
        stmt.setString(2, ncc.getTenNCC());
        stmt.setString(3, ncc.getDiaChi());
        stmt.setString(4, ncc.getsDT());

        return stmt.executeUpdate() > 0;
    }

    // Xoa NCC
    public boolean deleteNCC(String maNCC) throws SQLException {
        String sql = "DELETE FROM [dbo].[NhaCungCap]\r\n" + "      WHERE MaNCC = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maNCC);

        return stmt.executeLargeUpdate() > 0;
    }

    // Update NCC
    public boolean Update(NhaCungCap ncc) throws SQLException {
        String sql = "\r\n" + "UPDATE [dbo].[NhaCungCap]\r\n" + "   SET [MaNCC] = ?\r\n" + "      ,[TenNCC] = ?\r\n"
                + "      ,[DiaChi] = ?\r\n" + "      ,[SDT] = ?\r\n" + " WHERE MaNCC = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, ncc.getMaNCC());
        stmt.setString(2, ncc.getTenNCC());
        stmt.setString(3, ncc.getDiaChi());
        stmt.setString(4, ncc.getsDT());
        stmt.setString(5, ncc.getMaNCC());

        return stmt.executeUpdate() > 0;
    }

    // Tim kiem NCC theo ma NCC
    public NhaCungCap TimKiemNCCIsMaNCC(String maNCC) throws SQLException {
        String sql = "SELECT [MaNCC]\r\n" + "      ,[TenNCC]\r\n" + "      ,[DiaChi]\r\n" + "      ,[SDT]\r\n"
                + "  FROM [dbo].[NhaCungCap]\r\n" + "  WHERE MaNCC = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maNCC);

        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            String tenNCC = rs.getString(2);
            String diaChi = rs.getString(3);
            String sDT = rs.getString(4);

            NhaCungCap ncc = new NhaCungCap(maNCC, tenNCC, diaChi, sDT);
            return ncc;
        }

        return null;
    }

    // Tim kiem NCC theo ten NCC
    public NhaCungCap TimKiemNCCIsTenNCC(String tenNCC) throws SQLException {
        String sql = "SELECT [MaNCC]\r\n" + "      ,[TenNCC]\r\n" + "      ,[DiaChi]\r\n" + "      ,[SDT]\r\n"
                + "  FROM [dbo].[NhaCungCap]\r\n" + "  WHERE TenNCC LIKE N'%' + ? + '%'";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, tenNCC);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            String maNCC = rs.getString("MaNCC");
            String diaChi = rs.getString("DiaChi");
            String sDT = rs.getString("SDT");

            NhaCungCap ncc = new NhaCungCap(maNCC, tenNCC, diaChi, sDT);
            return ncc;
        }

        return null;
    }

    //Danh sach NCC
    public List<NhaCungCap> DanhSachNCC() throws SQLException {
        String sql = "SELECT * FROM [dbo].[NhaCungCap]";

        List<NhaCungCap> nhaCungCaps = new ArrayList<>();
        PreparedStatement stmt = con.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            String maNCC = rs.getString("MaNCC");
            String tenNCC = rs.getString("TenNCC");
            String diaChi = rs.getString("DiaChi");
            String sDT = rs.getString("SDT");

            NhaCungCap ncc = new NhaCungCap(maNCC, tenNCC, diaChi, sDT);
            nhaCungCaps.add(ncc);
        }

        return nhaCungCaps;
    }

    public List<String> DanhSachTenNCC() throws SQLException {
        String sql = "SELECT TenNCC FROM [dbo].[NhaCungCap]";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        List<String> nccList = new ArrayList<String>();
        while (rs.next()) {
            String nxb = rs.getString("TenNCC");
            nccList.add(nxb);
        }
        return nccList;
    }

    public String getMaNCC(String tenNCC) throws SQLException {
        String sql = "SELECT MaNCC FROM [dbo].[NhaCungCap] WHERE TenNCC LIKE N'%' + ? + '%'";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1, tenNCC);
        ResultSet rs = pstmt.executeQuery();
        String maNCC = null;
        if (rs.next()) {
            maNCC = rs.getString("MaNCC");
        }
        return maNCC;
    }
}

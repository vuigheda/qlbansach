/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.Account;

public class AccountDAO {
	private Connection con;

	public AccountDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	public Account checkLogin(String taiKhoan, String matKhau) throws Exception {
		String sql = "Select * From Account " + " Where TaiKhoan= ? and MatKhau= ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, taiKhoan);
		stmt.setString(2, matKhau);
		try (ResultSet rs = stmt.executeQuery();) {
			if (rs.next()) {
				Account ac = new Account();
				ac.setTaiKhoan(taiKhoan);
				ac.setQuyenHan(rs.getInt("QuyenHan"));
				return ac;
			}

		}
		return null;

	}

	public boolean insert(Account ac) throws Exception {
		String sql = "INSERT INTO [dbo].[Account] ([TaiKhoan],[MatKhau],[QuyenHan])" + "values(?,?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setString(1, ac.getTaiKhoan());
			pstmt.setString(2, ac.getMatKhau());
			pstmt.setInt(3, ac.getQuyenHan());
			return pstmt.executeUpdate() > 0;
		}
	}
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */
import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.LoaiSach;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LoaiSachDAO {

	private Connection con;

	public LoaiSachDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	// Them loai sach
	public boolean insert(LoaiSach loaiSach) throws SQLException {
		String sql = "INSERT INTO [dbo].[LoaiSach]\r\n" + "           ([MaLoaiSach]\r\n"
				+ "           ,[TenLoaiSach])\r\n" + "     VALUES\r\n" + "           (?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, loaiSach.getMaLoaiSach());
		stmt.setString(2, loaiSach.getTenLoaiSach());

		return stmt.executeUpdate() > 0;
	}

	// Xoa loai sach
	public boolean deleteLoaiSach(String maLS) throws SQLException {
		String sql = "DELETE FROM [dbo].[LoaiSach]\r\n" + "      WHERE MaLoaiSach = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maLS);

		return stmt.executeLargeUpdate() > 0;
	}

	// Update loai sach
	public boolean Update(LoaiSach loaiSach) throws SQLException {
		String sql = "UPDATE [dbo].[LoaiSach]\r\n" + "   SET [MaLoaiSach] = ?\r\n" + "      ,[TenLoaiSach] = ?\r\n"
				+ " WHERE MaLoaiSach = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, loaiSach.getMaLoaiSach());
		stmt.setString(2, loaiSach.getTenLoaiSach());
		stmt.setString(3, loaiSach.getMaLoaiSach());

		return stmt.executeUpdate() > 0;
	}

	// Tim kiem loai sach theo ma
	public LoaiSach TimKiemLSIsMa(String maLS) throws SQLException {
		String sql = "SELECT [MaLoaiSach]\r\n" + "      ,[TenLoaiSach]\r\n" + "  FROM [dbo].[LoaiSach]\r\n"
				+ "  WHERE MaLoaiSach = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maLS);

		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			String tenLoaiSach = rs.getString(2);

			LoaiSach ls = new LoaiSach(maLS, tenLoaiSach);
			return ls;
		}

		return null;
	}

	// Tim kiem loai sach theo ten
	public LoaiSach TimKiemLSIsTen(String tenLS) throws SQLException {
		String sql = "SELECT [MaLoaiSach]\r\n" + "      ,[TenLoaiSach]\r\n" + "  FROM [dbo].[LoaiSach]\r\n"
				+ "  WHERE TenLoaiSach = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, tenLS);

		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			String maLoaiSach = rs.getString("MaLoaiSach");

			LoaiSach ls = new LoaiSach(maLoaiSach, tenLS);
			return ls;
		}

		return null;
	}

	// Danh sach loai sach
	public List<LoaiSach> DanhSachLS() throws SQLException {
		String sql = "SELECT * FROM [dbo].[LoaiSach]";
		List<LoaiSach> loaiSachs = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			LoaiSach ls = new LoaiSach();
			ls.setMaLoaiSach(rs.getString("MaLoaiSach"));
			ls.setTenLoaiSach(rs.getString("TenLoaiSach"));
			loaiSachs.add(ls);
		}

		return loaiSachs;
	}

	public List<String> DanhSachTenTheLoai() throws SQLException {
		String sql = "SELECT TenLoaiSach FROM [dbo].[LoaiSach]";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		List<String> theLoaiList = new ArrayList<String>();
		while (rs.next()) {
			String nxb = rs.getString("TenLoaiSach");
			theLoaiList.add(nxb);
		}
		return theLoaiList;
	}

	public String getMaLS(String tenLS) throws SQLException {
		String sql = "SELECT MaLoaiSach FROM [dbo].[LoaiSach] WHERE TenLoaiSach LIKE N'%' + ? + '%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, tenLS);
		ResultSet rs = pstmt.executeQuery();
		String maLS = null;
		if (rs.next()) {
			maLS = rs.getString("MaLoaiSach");
		}
		return maLS;
	}
}

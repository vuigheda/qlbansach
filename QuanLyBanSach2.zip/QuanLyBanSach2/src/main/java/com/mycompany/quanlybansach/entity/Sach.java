/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

/**
 *
 * @author quang
 */


public class Sach extends SanPham{
	private NhaXuatBan maNXB;
	private TacGia maTG;
	private LoaiSach maLoaiSach;
	public Sach() {
		super();
	}
	public Sach(String maSP, String tenSP, String loaiSP, int soLuong, double donGia, NhaXuatBan maNXB, TacGia maTG,
			LoaiSach maLoaiSach) {
		super(maSP, tenSP, loaiSP, soLuong, donGia);
		this.maNXB = maNXB;
		this.maTG = maTG;
		this.maLoaiSach = maLoaiSach;
	}
	public NhaXuatBan getMaNXB() {
		return maNXB;
	}
	public void setMaNXB(NhaXuatBan maNXB) {
		this.maNXB = maNXB;
	}
	public TacGia getMaTG() {
		return maTG;
	}
	public void setMaTG(TacGia maTG) {
		this.maTG = maTG;
	}
	public LoaiSach getMaLoaiSach() {
		return maLoaiSach;
	}
	public void setMaLoaiSach(LoaiSach maLoaiSach) {
		this.maLoaiSach = maLoaiSach;
	}

	@Override
	public String toString() {
		return "Sach [maNXB=" + maNXB + ", maTG=" + maTG + ", maLoaiSach=" + maLoaiSach + "]";
	}


}


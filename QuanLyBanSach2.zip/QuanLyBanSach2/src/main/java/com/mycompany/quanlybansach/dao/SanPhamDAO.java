/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.SanPham;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SanPhamDAO {
	private Connection con;

	public SanPhamDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	// Them san pham
	public boolean insert(SanPham sp) throws SQLException {
		String sql = "INSERT INTO [dbo].[SanPham]\r\n" + "           ([MaSP]\r\n" + "           ,[LoaiSP]\r\n"
				+ "           ,[TenSP]\r\n" + "           ,[SoLuong]\r\n" + "           ,[DonGia])\r\n"
				+ "     VALUES\r\n" + "           (?, ?, ?, ?, ?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, sp.getMaSP());
		stmt.setString(2, sp.getLoaiSP());
		stmt.setString(3, sp.getTenSP());
		stmt.setInt(4, sp.getSoLuong());
		stmt.setDouble(5, sp.getDonGia());

		return stmt.executeUpdate() > 0;
	}

	// Update san pham
	public boolean update(SanPham sp) throws SQLException {

		String sql = "UPDATE [dbo].[SanPham]\r\n" + "   SET [MaSP] = ?\r\n" + "      ,[LoaiSP] = ?\r\n"
				+ "      ,[TenSP] = ?\r\n" + "      ,[SoLuong] = ?\r\n" + "      ,[DonGia] = ?\r\n" + " WHERE MaSP = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, sp.getMaSP());
		stmt.setString(2, sp.getLoaiSP());
		stmt.setString(3, sp.getTenSP());
		stmt.setInt(4, sp.getSoLuong());
		stmt.setDouble(5, sp.getDonGia());
		stmt.setString(6, sp.getMaSP());

		return stmt.executeUpdate() > 0;
	}

	public boolean updateTangSanPham(String maSP, int soLuong) throws SQLException {

		String sql = "UPDATE SanPham SET SoLuong = SoLuong + ? WHERE MaSP = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setDouble(1, soLuong);
		stmt.setString(2, maSP);

		return stmt.executeUpdate() > 0;
	}

	public boolean updateGiamSanPham(String maSP, int soLuong) throws SQLException {

		String sql = "UPDATE SanPham SET SoLuong = SoLuong - ? WHERE MaSP = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setDouble(1, soLuong);
		stmt.setString(2, maSP);

		return stmt.executeUpdate() > 0;
	}

	public int getSoLuongSanPham(String maSP) throws SQLException {
		int soLuong = 0;
		String sql = "SELECT SoLuong FROM SanPham WHERE MaSP = ?";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maSP);

		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			soLuong = rs.getInt("SoLuong");
		}

		return soLuong;
	}

	// Xoa san pham theo masp
	public boolean deleteMaSP(String maSP) throws SQLException {

		String sql = "DELETE FROM [dbo].[SanPham]\r\n" + "		WHERE MaSP = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maSP);
		return stmt.executeLargeUpdate() > 0;
	}

	// Tim kiem san pham theo ma san pham
	public SanPham TimKiemSPIsMaSP(String maSP) throws SQLException {
		String sql = "SELECT * FROM [dbo].[SanPham] WHERE MaSP = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maSP);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			String loaiSP = rs.getString("LoaiSP");
			String tenSP = rs.getString("TenSP");
			int soLuong = rs.getInt("SoLuong");
			double donGia = rs.getDouble("DonGia");

			SanPham sp = new SanPham(maSP, loaiSP, tenSP, soLuong, donGia);
			return sp;
		}
		return null;
	}

	// Tim kiem theo loai san pham
	public List<SanPham> TimKiemSPIsLoaiSP(String loaiSP) throws SQLException {
		String sql = "SELECT * FROM [dbo].[SanPham] WHERE LoaiSP = ?";
		List<SanPham> dsSP = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, loaiSP);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String maSP = rs.getString("MaSP");
			String tenSP = rs.getString("TenSP");
			int soLuong = rs.getInt("SoLuong");
			double donGia = rs.getDouble("DonGia");

			SanPham sp = new SanPham(maSP, loaiSP, tenSP, soLuong, donGia);
			dsSP.add(sp);
		}
		return dsSP;
	}

	// Tim kiem san pham theo ten san pham
	public SanPham TimKiemSPIsTenSP(String tenSP) throws SQLException {
		String sql = "SELECT * FROM [dbo].[SanPham] WHERE TenSP = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, tenSP);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			String maSP = rs.getString("MaSP");
			String loaiSP = rs.getString("LoaiSP");
			int soLuong = rs.getInt("SoLuong");
			double donGia = rs.getDouble("DonGia");

			SanPham sp = new SanPham(maSP, loaiSP, tenSP, soLuong, donGia);
			return sp;
		}
		return null;
	}

	// Hien thi danh sach san pham
	public List<SanPham> DsSanPham() throws SQLException {
		String sql = "SELECT * FROM [dbo].[SanPham]";
		List<SanPham> dsSP = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String maSP = rs.getString(1);
			String loaiSP = rs.getString(2);
			String tenSP = rs.getString(3);
			int soLuong = rs.getInt(4);
			double donGia = rs.getDouble(5);

			SanPham sp = new SanPham(maSP, loaiSP, tenSP, soLuong, donGia);
			dsSP.add(sp);
		}

		return dsSP;

	}

	public List<BookDTO> getBooksInfo() throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia "
				+ "FROM SanPham sp " + "INNER JOIN Sach s ON sp.MaSP = s.MaSP "
				+ "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB "
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach "
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG";

		PreparedStatement statement = con.prepareStatement(query);
		ResultSet resultSet = statement.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public BookDTO listSachTheoMaSP(String MaSP) throws SQLException {
		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n" + "WHERE sp.MaSP LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, MaSP);
		ResultSet resultSet = stmt.executeQuery();

		if (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			return book;
		}

		return null;
	}

	public BookDTO listSachTheoTenSP(String TenSP) throws SQLException {
		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n" + "WHERE sp.TenSP LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, TenSP);
		ResultSet resultSet = stmt.executeQuery();

		if (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			return book;
		}

		return null;
	}

	public List<BookDTO> listSachTheoNXB(String tenNXB) throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n" + "WHERE TenNXB LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenNXB);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public BookDTO bookDTOTheoMaSP(String MaSP) throws SQLException {
		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n" + "WHERE sp.MaSP LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, MaSP);
		ResultSet resultSet = stmt.executeQuery();

		if (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			return book;
		}

		return null;
	}

	public List<BookDTO> listSachTheoTacGia(String tenTG) throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n" + "WHERE TenTG LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenTG);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}
		return books;
	}

	public List<BookDTO> listSachTheoLoaiSach(String tenLS) throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n" + "WHERE TenLoaiSach LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenLS);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public List<BookDTO> listSachTheoLoaiSachAndTenNXB(String tenLS, String tenNXB) throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n"
				+ "WHERE TenLoaiSach LIKE N'%' + ? + '%' AND TenNXB LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenLS);
		stmt.setString(2, tenNXB);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public List<BookDTO> listSachTheoLoaiSachAndTenTacGia(String tenLS, String tenTacGia) throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n"
				+ "WHERE TenLoaiSach LIKE N'%' + ? + '%' AND TenTG LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenLS);
		stmt.setString(2, tenTacGia);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public List<BookDTO> listSachTheoTenNXBAndTenTacGia(String tenNXB, String tenTacGia) throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n"
				+ "WHERE TenNXB LIKE N'%' + ? + '%' AND TenTG LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenNXB);
		stmt.setString(2, tenTacGia);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public List<BookDTO> listDanhSachIsLoaiSachAndTenNachTheXBAndTenTG(String tenLS, String tenNXB, String tenTacGia)
			throws SQLException {
		List<BookDTO> books = new ArrayList<>();

		String query = "SELECT sp.MaSP, sp.TenSP, nxb.TenNXB, ls.TenLoaiSach, tg.TenTG, sp.SoLuong, sp.DonGia FROM SanPham sp \r\n"
				+ "INNER JOIN Sach s ON sp.MaSP = s.MaSP \r\n" + "INNER JOIN NhaXuatBan nxb ON s.MaNXB = nxb.MaNXB \r\n"
				+ "INNER JOIN LoaiSach ls ON s.MaLoaiSach = ls.MaLoaiSach \r\n"
				+ "INNER JOIN TacGia tg ON s.MaTG = tg.MaTG\r\n"
				+ "WHERE TenLoaiSach LIKE ? AND TenNXB LIKE ? AND TenTG LIKE ?";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, "%" + tenLS + "%");
		stmt.setString(2, "%" + tenNXB + "%");
		stmt.setString(3, "%" + tenTacGia + "%");

		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			BookDTO book = new BookDTO();
			book.setMaSP(resultSet.getString("MaSP"));
			book.setTenSP(resultSet.getString("TenSP"));
			book.setTenNXB(resultSet.getString("TenNXB"));
			book.setTenLoaiSach(resultSet.getString("TenLoaiSach"));
			book.setTenTG(resultSet.getString("TenTG"));
			book.setSoLuong(resultSet.getInt("SoLuong"));
			book.setDonGia(resultSet.getFloat("DonGia"));
			books.add(book);
		}

		return books;
	}

	public List<SanPham> getLoaiSP(String tenLoaiSP) throws SQLException {
		String sql = "SELECT MaSP, TenSP, SoLuong FROM [dbo].[SanPham] WHERE LoaiSP LIKE N'%' + ? + '%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, tenLoaiSP);
		ResultSet rs = pstmt.executeQuery();
		List<SanPham> sanPhams = new ArrayList<>();
		while (rs.next()) {
			SanPham sp = new SanPham();
			sp.setMaSP(rs.getString("MaSP"));
			sp.setTenSP(rs.getString("TenSP"));
			sp.setSoLuong(rs.getInt("SoLuong"));
			sanPhams.add(sp);
		}
		return sanPhams;
	}

	public List<DungCuHocTapDTO> getDungCuHocTapsInfo() throws SQLException {
		List<DungCuHocTapDTO> cuHocTapDTOs = new ArrayList<>();

		String query = "SELECT	sp.MaSP, TenSP, TenNCC, SoLuong, DonGia FROM [dbo].[SanPham] sp\r\n"
				+ "INNER JOIN [dbo].[DungCuHocTap] dcht ON sp.MaSP = dcht.MaSP\r\n"
				+ "INNER JOIN [dbo].[NhaCungCap] ncc ON dcht.MaNCC = ncc.MaNCC";

		PreparedStatement statement = con.prepareStatement(query);
		ResultSet resultSet = statement.executeQuery();

		while (resultSet.next()) {
			DungCuHocTapDTO dungCuHocTapDTO = new DungCuHocTapDTO();
			dungCuHocTapDTO.setMaSP(resultSet.getString("MaSP"));
			dungCuHocTapDTO.setTenSP(resultSet.getString("TenSP"));
			;
			dungCuHocTapDTO.setTenNCC(resultSet.getString("TenNCC"));
			dungCuHocTapDTO.setSoLuong(resultSet.getInt("SoLuong"));
			dungCuHocTapDTO.setDonGia(resultSet.getFloat("DonGia"));
			cuHocTapDTOs.add(dungCuHocTapDTO);
		}

		return cuHocTapDTOs;
	}

	public DungCuHocTapDTO listDCHTIsTenSP(String tenSP) throws SQLException {
		@SuppressWarnings("unused")
		List<DungCuHocTapDTO> cuHocTapDTOs = new ArrayList<>();
		String query = "SELECT	sp.MaSP, TenSP, TenNCC, SoLuong, DonGia FROM [dbo].[SanPham] sp\r\n"
				+ "INNER JOIN [dbo].[DungCuHocTap] dcht ON sp.MaSP = dcht.MaSP\r\n"
				+ "INNER JOIN [dbo].[NhaCungCap] ncc ON dcht.MaNCC = ncc.MaNCC\r\n"
				+ "WHERE sp.TenSP LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenSP);
		ResultSet resultSet = stmt.executeQuery();

		if (resultSet.next()) {
			DungCuHocTapDTO dungCuHocTapDTO = new DungCuHocTapDTO();
			dungCuHocTapDTO.setMaSP(resultSet.getString("MaSP"));
			dungCuHocTapDTO.setTenSP(resultSet.getString("TenSP"));
			dungCuHocTapDTO.setTenNCC(resultSet.getString("TenNCC"));
			dungCuHocTapDTO.setSoLuong(resultSet.getInt("SoLuong"));
			dungCuHocTapDTO.setDonGia(resultSet.getFloat("DonGia"));
			return dungCuHocTapDTO;
		}

		return null;
	}

	public DungCuHocTapDTO listDCHTIsMaSP(String MaSP) throws SQLException {
		@SuppressWarnings("unused")
		List<DungCuHocTapDTO> cuHocTapDTOs = new ArrayList<>();
		String query = "SELECT	sp.MaSP, TenSP, TenNCC, SoLuong, DonGia FROM [dbo].[SanPham] sp\r\n"
				+ "INNER JOIN [dbo].[DungCuHocTap] dcht ON sp.MaSP = dcht.MaSP\r\n"
				+ "INNER JOIN [dbo].[NhaCungCap] ncc ON dcht.MaNCC = ncc.MaNCC\r\n"
				+ "WHERE sp.MaSP LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, MaSP);
		ResultSet resultSet = stmt.executeQuery();

		if (resultSet.next()) {
			DungCuHocTapDTO dungCuHocTapDTO = new DungCuHocTapDTO();
			dungCuHocTapDTO.setMaSP(resultSet.getString("MaSP"));
			dungCuHocTapDTO.setTenSP(resultSet.getString("TenSP"));
			dungCuHocTapDTO.setTenNCC(resultSet.getString("TenNCC"));
			dungCuHocTapDTO.setSoLuong(resultSet.getInt("SoLuong"));
			dungCuHocTapDTO.setDonGia(resultSet.getFloat("DonGia"));
			return dungCuHocTapDTO;
		}

		return null;
	}

	public List<DungCuHocTapDTO> listDCHTIsTenNhaCungCap(String tenNCC) throws SQLException {
		List<DungCuHocTapDTO> cuHocTapDTOs = new ArrayList<>();

		String query = "SELECT	sp.MaSP, TenSP, TenNCC, SoLuong, DonGia FROM [dbo].[SanPham] sp\r\n"
				+ "INNER JOIN [dbo].[DungCuHocTap] dcht ON sp.MaSP = dcht.MaSP\r\n"
				+ "INNER JOIN [dbo].[NhaCungCap] ncc ON dcht.MaNCC = ncc.MaNCC\r\n"
				+ "WHERE TenNCC LIKE N'%' + ? + '%'";

		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, tenNCC);
		ResultSet resultSet = stmt.executeQuery();

		while (resultSet.next()) {
			DungCuHocTapDTO dungCuHocTapDTO = new DungCuHocTapDTO();
			dungCuHocTapDTO.setMaSP(resultSet.getString("MaSP"));
			dungCuHocTapDTO.setTenSP(resultSet.getString("TenSP"));
			;
			dungCuHocTapDTO.setTenNCC(resultSet.getString("TenNCC"));
			dungCuHocTapDTO.setSoLuong(resultSet.getInt("SoLuong"));
			dungCuHocTapDTO.setDonGia(resultSet.getFloat("DonGia"));
			cuHocTapDTOs.add(dungCuHocTapDTO);
		}

		return cuHocTapDTOs;
	}

	public class BookDTO {
		private String maSP;
		private String tenSP;
		private String tenNXB;
		private String tenLoaiSach;
		private String tenTG;
		private int soLuong;
		private float donGia;

		public String getMaSP() {
			return maSP;
		}

		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}

		public String getTenSP() {
			return tenSP;
		}

		public void setTenSP(String tenSP) {
			this.tenSP = tenSP;
		}

		public String getTenNXB() {
			return tenNXB;
		}

		public void setTenNXB(String tenNXB) {
			this.tenNXB = tenNXB;
		}

		public String getTenLoaiSach() {
			return tenLoaiSach;
		}

		public void setTenLoaiSach(String tenLoaiSach) {
			this.tenLoaiSach = tenLoaiSach;
		}

		public String getTenTG() {
			return tenTG;
		}

		public void setTenTG(String tenTG) {
			this.tenTG = tenTG;
		}

		public int getSoLuong() {
			return soLuong;
		}

		public void setSoLuong(int soLuong) {
			this.soLuong = soLuong;
		}

		public float getDonGia() {
			return donGia;
		}

		public void setDonGia(float donGia) {
			this.donGia = donGia;
		}
	}

	public class DungCuHocTapDTO {
		private String maSP;
		private String tenSP;
		private String tenNCC;
		private int soLuong;
		private float donGia;

		public String getMaSP() {
			return maSP;
		}

		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}

		public String getTenSP() {
			return tenSP;
		}

		public void setTenSP(String tenSP) {
			this.tenSP = tenSP;
		}

		public String getTenNCC() {
			return tenNCC;
		}

		public void setTenNCC(String tenNCC) {
			this.tenNCC = tenNCC;
		}

		public int getSoLuong() {
			return soLuong;
		}

		public void setSoLuong(int soLuong) {
			this.soLuong = soLuong;
		}

		public float getDonGia() {
			return donGia;
		}

		public void setDonGia(float donGia) {
			this.donGia = donGia;
		}
	}
}

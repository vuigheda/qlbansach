/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.TacGia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TacGiaDAO {
	private Connection con;

	public TacGiaDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

// Them tac gia
	public boolean ThemTG(TacGia tg) {
		try {
			String sql = "\r\n" + "INSERT INTO [dbo].[TacGia]\r\n" + "           ([MaTG]\r\n"
					+ "           ,[TenTG]\r\n" + "           ,[QuocTich])\r\n" + "     VALUES\r\n"
					+ "           (?, ?, ?)";

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, tg.getMaTacGia());
			stmt.setString(2, tg.getTenTacGia());
			stmt.setString(3, tg.getQuocTich());

			int n = stmt.executeUpdate();
			return n > 0;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

//Update tac gia
	public boolean update(TacGia tg) throws SQLException {

		String sql = "UPDATE [dbo].[TacGia]\r\n" + "   SET [MaTG] = ?\r\n" + "      ,[TenTG] = ?\r\n"
				+ "      ,[QuocTich] = ?\r\n" + " WHERE MaTG = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, tg.getMaTacGia());
		stmt.setString(2, tg.getTenTacGia());
		stmt.setString(3, tg.getQuocTich());
		stmt.setString(4, tg.getMaTacGia());

		return stmt.executeUpdate() > 0;

	}

//Xoa tac gia theo ma
	public boolean deleteMaTG(String maTG) throws SQLException {

		String sql = "DELETE FROM [dbo].[TacGia]\r\n" + "		WHERE MaTG = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maTG);

		return stmt.executeLargeUpdate() > 0;

	}

//Hien thi danh sach tac gia
	public List<TacGia> DSTacGia() throws SQLException {
		String sql = "SELECT * FROM [dbo].[TacGia]";
		List<TacGia> dsTG = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String maTG = rs.getString(1);
			String tenTG = rs.getString(2);
			String quocTich = rs.getString(3);

			TacGia tg = new TacGia(maTG, tenTG, quocTich);
			dsTG.add(tg);
		}

		return dsTG;
	}

//Tim kiem tac gia bang maTG
	public TacGia getTacGiaTheoMaTG(String maTG) throws SQLException {
		String sql = "SELECT [MaTG]\r\n" + "      ,[TenTG]\r\n" + "      ,[QuocTich]\r\n" + "  FROM [dbo].[TacGia]\r\n"
				+ "  WHERE MaTG = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maTG);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			String tenTG = rs.getString(2);
			String quocTich = rs.getString(3);

			TacGia tg = new TacGia(maTG, tenTG, quocTich);
			return tg;
		}

		return null;
	}

	public List<String> DanhSachTenTacGia() throws SQLException {
		String sql = "SELECT TenTG FROM [dbo].[TacGia]";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		List<String> listTenTG = new ArrayList<String>();
		while (rs.next()) {
			String nxb = rs.getString("TenTG");
			listTenTG.add(nxb);
		}
		return listTenTG;
	}

	  public String getMaTG(String tenTG) throws SQLException {
	        String sql =  "SELECT [MaTG] FROM [dbo].[TacGia] WHERE [TenTG] LIKE N'%' + ? + '%'";
	        PreparedStatement pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, tenTG);
	        ResultSet rs = pstmt.executeQuery();
	        String maTG = null;
	        if (rs.next()) {
	            maTG = rs.getString("MaTG");
	        }
	        return maTG;
	    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.DatSach;
import com.mycompany.quanlybansach.entity.KhachHang;
import com.mycompany.quanlybansach.entity.NhanVien;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class DatSachDAO {
	private Connection con;

	public DatSachDAO() {
		con = ConnectDB.getInstance().getConnection();
	}

	// Dat sach:
	public boolean addDatSach(DatSach ds) throws SQLException {
		String sql = "INSERT INTO [dbo].[DatSach]\r\n" + "           ([MaDS]\r\n" + "           ,[MaKH]\r\n"
				+ "           ,[MaNV]\r\n" + "           ,[TrangThai]\r\n" + "           ,[NgayDatSach]\r\n"
				+ "           ,[TongTien]\r\n" + "           ,[TienKhachTra]\r\n" + "           ,[TienKhachDu])\r\n"
				+ "     VALUES\r\n" + "           (?,?,?,?,?,?,?,?)";

		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, ds.getMaDS());
		stmt.setString(2, ds.getMaKH().getMaKH());
		stmt.setString(3, ds.getMaNV().getMaNV());
		stmt.setString(4, ds.getTrangThai());
		stmt.setTimestamp(5, ds.getThoiGianDat());
		stmt.setDouble(6, ds.getTongTien());
		stmt.setDouble(7, ds.getTienKhachTra());
		stmt.setDouble(8, ds.getTienKhacDu());

		return stmt.executeUpdate() > 0;
	}

	// Update dat sach

	public boolean Update(DatSach ds) throws SQLException {
		String sql = "UPDATE [dbo].[DatSach]\r\n" + "   SET [MaDS] = ?\r\n" + "      ,[MaKH] = ?\r\n"
				+ "      ,[MaNV] = ?\r\n" + "      ,[TrangThai] = ?\r\n" + "      ,[NgayDatSach] = ?\r\n"
				+ "      ,[TongTien] = ?\r\n" + "      ,[TienKhachTra] = ?\r\n" + "      ,[TienKhachDu] = ?\r\n"
				+ " WHERE MaDS = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, ds.getMaDS());
		stmt.setString(2, ds.getMaKH().getMaKH());
		stmt.setString(3, ds.getMaNV().getMaNV());
		stmt.setString(4, ds.getTrangThai());
		stmt.setTimestamp(5, ds.getThoiGianDat());
		stmt.setDouble(6, ds.getTongTien());
		stmt.setDouble(7, ds.getTienKhachTra());
		stmt.setDouble(8, ds.getTienKhacDu());
		stmt.setString(9, ds.getMaDS());

		return stmt.executeUpdate() > 0;

	}

	public boolean XoaDatSach(String maDS) throws SQLException {

		String sql = "DELETE FROM [dbo].[DatSach]\r\n" + "		WHERE MaDS = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maDS);

		return stmt.executeLargeUpdate() > 0;

	}

	// Danh sach dat sach
	public List<DatSach> DanhSachDatSach() throws SQLException {
		String sql = "SELECT * FROM [dbo].[DatSach]";
		List<DatSach> dsDS = new ArrayList<>();
		PreparedStatement stmt = con.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			DatSach ds = new DatSach();
			KhachHang kh = new KhachHang();
			NhanVien nv = new NhanVien();
			ds.setMaDS(rs.getString("MaDS"));
			kh.setMaKH(rs.getString("MaKH"));
			nv.setMaNV(rs.getString("MaNV"));
			ds.setMaKH(kh);
			ds.setMaNV(nv);
			ds.setTrangThai(rs.getString("TrangThai"));
			ds.setThoiGianDat(rs.getTimestamp("NgayDatSach"));
			ds.setTongTien(rs.getDouble("TongTien"));
			ds.setTienKhachTra(rs.getDouble("TienKhachTra"));
			ds.setTienKhacDu(rs.getDouble("TienKhachDu"));

			dsDS.add(ds);
		}

		return dsDS;

	}

	public DatSach getDatSachTheoMaDS(String maDS) throws SQLException {
		String sql = "SELECT * FROM [dbo].[DatSach] WHERE MaDS = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maDS);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			DatSach ds = new DatSach();
			KhachHang kh = new KhachHang();
			NhanVien nv = new NhanVien();
			ds.setMaDS(rs.getString("MaDS"));
			kh.setMaKH(rs.getString("MaKH"));
			nv.setMaNV(rs.getString("MaNV"));
			ds.setMaKH(kh);
			ds.setMaNV(nv);
			ds.setTrangThai(rs.getString("TrangThai"));
			ds.setThoiGianDat(rs.getTimestamp("NgayDatSach"));
			ds.setTongTien(rs.getDouble("TongTien"));
			ds.setTienKhachTra(rs.getDouble("TienKhachTra"));
			ds.setTienKhacDu(rs.getDouble("TienKhachDu"));

			return ds;
		}

		return null;
	}

	public List<DatSach> getDatSachTheoMaKH(String maKH) throws SQLException {
		String sql = "SELECT * FROM [dbo].[DatSach] WHERE MaKH = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maKH);
		ResultSet rs = stmt.executeQuery();
		List<DatSach> datSachs = new ArrayList<>();
		while (rs.next()) {
			DatSach ds = new DatSach();
			KhachHang kh = new KhachHang();
			NhanVien nv = new NhanVien();
			ds.setMaDS(rs.getString("MaDS"));
			kh.setMaKH(rs.getString("MaKH"));
			nv.setMaNV(rs.getString("MaNV"));
			ds.setMaKH(kh);
			ds.setMaNV(nv);
			ds.setTrangThai(rs.getString("TrangThai"));
			ds.setThoiGianDat(rs.getTimestamp("NgayDatSach"));
			ds.setTongTien(rs.getDouble("TongTien"));
			ds.setTienKhachTra(rs.getDouble("TienKhachTra"));
			ds.setTienKhacDu(rs.getDouble("TienKhachDu"));

			datSachs.add(ds);
		}
		return datSachs;
	}

	public String generateMaDS() throws SQLException {
		String MaDS = null;
		String prefix = "DS";
		String sql = "SELECT MAX(MaDS) FROM DatSach";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);

		rs.next();
		String maxMaDS = rs.getString(1);
		int index = 1;

		if (maxMaDS != null) {
			String numericPart = maxMaDS.substring(prefix.length()).trim();
			index = Integer.parseInt(numericPart) + 1;
		}

		MaDS = prefix + String.format("%03d", index);

		return MaDS;
	}

	public DatSachDTO getDatSachDTOIsMaDS(String maDS) throws SQLException {
		String sql = "SELECT    dbo.DatSach.MaDS, dbo.KhachHang.TenKH, dbo.NhanVien.TenNV, dbo.DatSach.TrangThai, dbo.DatSach.NgayDatSach, dbo.DatSach.TongTien, dbo.DatSach.TienKhachTra, dbo.DatSach.TienKhachDu\r\n"
				+ "FROM         dbo.DatSach INNER JOIN\r\n"
				+ "                      dbo.KhachHang ON dbo.DatSach.MaKH = dbo.KhachHang.MaKH INNER JOIN\r\n"
				+ "                      dbo.NhanVien ON dbo.DatSach.MaNV = dbo.NhanVien.MaNV\r\n"
				+ "WHERE dbo.DatSach.MaDS = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, maDS);
		ResultSet rs = stmt.executeQuery();
		DatSachDTO ds = new DatSachDTO();
		if (rs.next()) {
			ds.setMaDS(rs.getString("MaDS"));
			ds.setTenKH(rs.getString("TenKH"));
			ds.setTenNV(rs.getString("TenNV"));
			ds.setTrangThai(rs.getString("TrangThai"));
			ds.setThoiGianDat(rs.getTimestamp("NgayDatSach"));
			ds.setTongTien(rs.getDouble("TongTien"));
			ds.setTienKhachTra(rs.getDouble("TienKhachTra"));
			ds.setTienKhacDu(rs.getDouble("TienKhachDu"));
		}
		return ds;
	}

	public class DatSachDTO {
		private String maDS;
		private String tenKH;
		private String tenNV;
		private String trangThai;
		private Timestamp thoiGianDat;
		private double tongTien;
		private double tienKhachTra;
		private double tienKhacDu;

		public DatSachDTO() {
			super();
		}

		public DatSachDTO(String maDS, String tenKH, String tenNV, String trangThai, Timestamp thoiGianDat,
				double tongTien, double tienKhachTra, double tienKhacDu) {
			super();
			this.maDS = maDS;
			this.tenKH = tenKH;
			this.tenNV = tenNV;
			this.trangThai = trangThai;
			this.thoiGianDat = thoiGianDat;
			this.tongTien = tongTien;
			this.tienKhachTra = tienKhachTra;
			this.tienKhacDu = tienKhacDu;
		}

		public String getMaDS() {
			return maDS;
		}

		public void setMaDS(String maDS) {
			this.maDS = maDS;
		}

		public String getTenKH() {
			return tenKH;
		}

		public void setTenKH(String tenKH) {
			this.tenKH = tenKH;
		}

		public String getTenNV() {
			return tenNV;
		}

		public void setTenNV(String tenNV) {
			this.tenNV = tenNV;
		}

		public String getTrangThai() {
			return trangThai;
		}

		public void setTrangThai(String trangThai) {
			this.trangThai = trangThai;
		}

		public Timestamp getThoiGianDat() {
			return thoiGianDat;
		}

		public void setThoiGianDat(Timestamp thoiGianDat) {
			this.thoiGianDat = thoiGianDat;
		}

		public double getTongTien() {
			return tongTien;
		}

		public void setTongTien(double tongTien) {
			this.tongTien = tongTien;
		}

		public double getTienKhachTra() {
			return tienKhachTra;
		}

		public void setTienKhachTra(double tienKhachTra) {
			this.tienKhachTra = tienKhachTra;
		}

		public double getTienKhacDu() {
			return tienKhacDu;
		}

		public void setTienKhacDu(double tienKhacDu) {
			this.tienKhacDu = tienKhacDu;
		}

		@Override
		public String toString() {
			return "DatSachDTO [maDS=" + maDS + ", tenKH=" + tenKH + ", tenNV=" + tenNV + ", trangThai=" + trangThai
					+ ", thoiGianDat=" + thoiGianDat + ", tongTien=" + tongTien + ", tienKhachTra=" + tienKhachTra
					+ ", tienKhacDu=" + tienKhacDu + "]";
		}

	}
}

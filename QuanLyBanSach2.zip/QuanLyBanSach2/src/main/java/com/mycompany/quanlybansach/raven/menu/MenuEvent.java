package com.mycompany.quanlybansach.raven.menu;

import java.sql.SQLException;

public interface MenuEvent {
    public void selected(int index, int subIndex) throws SQLException;
    
}

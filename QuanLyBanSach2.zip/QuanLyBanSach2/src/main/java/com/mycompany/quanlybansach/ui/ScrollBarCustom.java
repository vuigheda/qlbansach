/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.ui;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JScrollBar;

/**
 *
 * @author quang
 */
public class ScrollBarCustom extends JScrollBar {

   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public ScrollBarCustom() {
        setUI(new com.mycompany.quanlybansach.ui.ModernScrollBarUI());
        setPreferredSize(new Dimension(8, 8));
        setForeground(new Color(48, 144, 216));
        setBackground(new Color(13,148,148));
    }
    
}

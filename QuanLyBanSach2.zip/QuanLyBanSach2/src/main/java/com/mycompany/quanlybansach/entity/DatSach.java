/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

import java.sql.Timestamp;

/**
 *
 * @author quang
 */

public class DatSach {
	private String maDS;
	private KhachHang maKH;
	private NhanVien maNV;
	private String trangThai;
	private Timestamp thoiGianDat;
	private double tongTien;
	private double tienKhachTra;
	private double tienKhacDu;

	public DatSach() {
		super();
	}

	public DatSach(String maDS, KhachHang maKH, NhanVien maNV, String trangThai, Timestamp thoiGianDat, double tongTien,
			double tienKhachTra, double tienKhacDu) {
		super();
		this.maDS = maDS;
		this.maKH = maKH;
		this.maNV = maNV;
		this.trangThai = trangThai;
		this.thoiGianDat = thoiGianDat;
		this.tongTien = tongTien;
		this.tienKhachTra = tienKhachTra;
		this.tienKhacDu = tienKhacDu;
	}

	public String getMaDS() {
		return maDS;
	}

	public void setMaDS(String maDS) {
		this.maDS = maDS;
	}

	public KhachHang getMaKH() {
		return maKH;
	}

	public void setMaKH(KhachHang maKH) {
		this.maKH = maKH;
	}

	public NhanVien getMaNV() {
		return maNV;
	}

	public void setMaNV(NhanVien maNV) {
		this.maNV = maNV;
	}

	public String getTrangThai() {
		return trangThai;
	}

	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}

	public Timestamp getThoiGianDat() {
		return thoiGianDat;
	}

	public void setThoiGianDat(Timestamp thoiGianDat) {
		this.thoiGianDat = thoiGianDat;
	}

	public double getTongTien() {
		return tongTien;
	}

	public void setTongTien(double tongTien) {
		this.tongTien = tongTien;
	}

	public double getTienKhachTra() {
		return tienKhachTra;
	}

	public void setTienKhachTra(double tienKhachTra) {
		this.tienKhachTra = tienKhachTra;
	}

	public double getTienKhacDu() {
		return tienKhacDu;
	}

	public void setTienKhacDu(double tienKhacDu) {
		this.tienKhacDu = tienKhacDu;
	}

	@Override
	public String toString() {
		return "DatSach [maDS=" + maDS + ", maKH=" + maKH + ", maNV=" + maNV + ", trangThai=" + trangThai
				+ ", thoiGianDat=" + thoiGianDat + ", tongTien=" + tongTien + ", tienKhachTra=" + tienKhachTra
				+ ", tienKhacDu=" + tienKhacDu + "]";
	}

}

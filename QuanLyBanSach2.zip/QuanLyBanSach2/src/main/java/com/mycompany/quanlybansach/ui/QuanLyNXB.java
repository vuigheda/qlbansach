package com.mycompany.quanlybansach.ui;

import com.mycompany.quanlybansach.connectDB.DataValidator;
import com.mycompany.quanlybansach.connectDB.MessageDialogConnectDB;
import com.mycompany.quanlybansach.dao.NhaXuatBanDAO;
import com.mycompany.quanlybansach.entity.NhaXuatBan;
import com.mycompany.quanlybansach.entity.Regex;
import com.mycompany.quanlybansach.ui.support.TableCustom;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class QuanLyNXB extends javax.swing.JPanel {

    private static final long serialVersionUID = 1L;
	private DefaultTableModel tblModel;
    private Regex regex;
    private GiaoDienChinh giaoDienChinh;

    public QuanLyNXB() {
        initComponents();

        initTable();

        regex = new Regex();
        TableCustom.apply(jScrollPane1, TableCustom.TableType.DEFAULT);
        jScrollPane1.getVerticalScrollBar().setUnitIncrement(20);
    }

    private void initTable() {
        tblModel = new DefaultTableModel();
        tblModel.setColumnIdentifiers(new String[]{"Mã NXB", "Tên NXB", "Địa chỉ", "Số điện thoại"});
        tblNXB.setModel(tblModel);

    }

    public void showNXB() throws SQLException {
        try {
            NhaXuatBanDAO dao = new NhaXuatBanDAO();
            List<NhaXuatBan> list = dao.DanhSachNXB();
            tblModel.setRowCount(0);
            for (NhaXuatBan it : list) {

                tblModel.addRow(new Object[]{
                    it.getMaNXB(), it.getTenNXB(), it.getDiaChi(), it.getsDT()
                });
            }
            tblModel.fireTableDataChanged();
        } catch (Exception e) {
            e.printStackTrace();
            //MessageDialogConnectDB.showConfirmDialog(parentForm, e.getMessage(), "Lỗi");
        }
    }

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlbg = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pnlthongtinNCC = new com.mycompany.quanlybansach.ui.support.PanelRound();
        lbltenNXB = new javax.swing.JLabel();
        lblmaNXB = new javax.swing.JLabel();
        lblSDTNXB = new javax.swing.JLabel();
        lbldiachiNXB = new javax.swing.JLabel();
        txtMaNXB = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
        txtTenNXB = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
        txtSDT = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
        txtDiaChi = new com.mycompany.quanlybansach.ui.support.TextFieldSuggestion();
        pnltableNXB = new com.mycompany.quanlybansach.ui.support.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblNXB = new javax.swing.JTable();
        pnlBTN = new com.mycompany.quanlybansach.ui.support.PanelRound();
        btnThem = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
        btnXoa = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
        btnCapNhat = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
        btnXoaTrang = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
        btnXemTatCa = new com.mycompany.quanlybansach.ui.support.ButtonCustom();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        pnlbg.setBackground(new java.awt.Color(99, 183, 183));
        pnlbg.setRequestFocusEnabled(false);

        jLabel1.setBackground(new java.awt.Color(99, 183, 183));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("QUẢN LÝ NHÀ XUẤT BẢN");

        pnlthongtinNCC.setBackground(new java.awt.Color(255, 255, 255));
        pnlthongtinNCC.setRoundBottomLeft(50);
        pnlthongtinNCC.setRoundBottomRight(50);
        pnlthongtinNCC.setRoundTopLeft(50);
        pnlthongtinNCC.setRoundTopRight(50);

        lbltenNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbltenNXB.setText("Tên NXB");

        lblmaNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblmaNXB.setText("Mã NXB");

        lblSDTNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblSDTNXB.setText("SĐT");

        lbldiachiNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbldiachiNXB.setText("Địa chỉ");

        javax.swing.GroupLayout pnlthongtinNCCLayout = new javax.swing.GroupLayout(pnlthongtinNCC);
        pnlthongtinNCC.setLayout(pnlthongtinNCCLayout);
        pnlthongtinNCCLayout.setHorizontalGroup(
            pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlthongtinNCCLayout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbltenNXB, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                    .addComponent(lblmaNXB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtMaNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTenNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(87, 87, 87)
                .addGroup(pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlthongtinNCCLayout.createSequentialGroup()
                        .addComponent(lbldiachiNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 472, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlthongtinNCCLayout.createSequentialGroup()
                        .addComponent(lblSDTNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlthongtinNCCLayout.setVerticalGroup(
            pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlthongtinNCCLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmaNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMaNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSDTNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlthongtinNCCLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                        .addGroup(pnlthongtinNCCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbldiachiNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbltenNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTenNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(50, 50, 50))
                    .addGroup(pnlthongtinNCCLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout pnltableNXBLayout = new javax.swing.GroupLayout(pnltableNXB);
        pnltableNXB.setLayout(pnltableNXBLayout);
        pnltableNXBLayout.setHorizontalGroup(
            pnltableNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnltableNXBLayout.setVerticalGroup(
            pnltableNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 460, Short.MAX_VALUE)
        );

        tblNXB.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        tblNXB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã NXB", "Tên NXB", "Địa Chỉ", "Số điện thoại"
            }
        ));
        tblNXB.setToolTipText("");
        tblNXB.setFocusCycleRoot(true);
        tblNXB.setGridColor(new java.awt.Color(255, 255, 255));
        tblNXB.setShowGrid(false);
        tblNXB.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tblNXBAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        tblNXB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNXBMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblNXB);

        pnlBTN.setBackground(new java.awt.Color(255, 255, 255));
        pnlBTN.setRoundBottomLeft(50);
        pnlBTN.setRoundBottomRight(50);
        pnlBTN.setRoundTopLeft(50);
        pnlBTN.setRoundTopRight(50);

        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-plus-24.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_clear_symbol_23px.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnCapNhat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/updated.png"))); // NOI18N
        btnCapNhat.setText("Cập nhật");
        btnCapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapNhatActionPerformed(evt);
            }
        });

        btnXoaTrang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/clean.png"))); // NOI18N
        btnXoaTrang.setText("Xóa trắng");
        btnXoaTrang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaTrangActionPerformed(evt);
            }
        });

        btnXemTatCa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8_search_in_list_23px.png"))); // NOI18N
        btnXemTatCa.setText("Xem tất cả");
        btnXemTatCa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXemTatCaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlBTNLayout = new javax.swing.GroupLayout(pnlBTN);
        pnlBTN.setLayout(pnlBTNLayout);
        pnlBTNLayout.setHorizontalGroup(
            pnlBTNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBTNLayout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addComponent(btnXemTatCa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnXoaTrang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCapNhat, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        pnlBTNLayout.setVerticalGroup(
            pnlBTNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBTNLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(pnlBTNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnXoaTrang, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCapNhat, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnXemTatCa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/S_dM1sxCbLN87yKjKtUE0gKi598rjPlqww.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/OIP.jpg"))); // NOI18N
        jLabel4.setText("jLabel4");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/a.JPG"))); // NOI18N
        jLabel3.setText("jLabel3");

        javax.swing.GroupLayout pnlbgLayout = new javax.swing.GroupLayout(pnlbg);
        pnlbg.setLayout(pnlbgLayout);
        pnlbgLayout.setHorizontalGroup(
            pnlbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlbgLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(pnlbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlbgLayout.createSequentialGroup()
                        .addGroup(pnlbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlbgLayout.createSequentialGroup()
                                .addGap(0, 247, Short.MAX_VALUE)
                                .addComponent(pnlBTN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1))
                        .addGap(253, 253, 253)
                        .addComponent(pnltableNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(pnlbgLayout.createSequentialGroup()
                        .addComponent(pnlthongtinNCC, javax.swing.GroupLayout.PREFERRED_SIZE, 881, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(pnlbgLayout.createSequentialGroup()
                .addGap(621, 621, 621)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlbgLayout.setVerticalGroup(
            pnlbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlbgLayout.createSequentialGroup()
                .addGap(343, 343, 343)
                .addComponent(pnltableNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlbgLayout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlbgLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlbgLayout.createSequentialGroup()
                        .addComponent(pnlthongtinNCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(pnlBTN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(jScrollPane1)))
                .addGap(147, 147, 147))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(pnlbg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlbg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnXemTatCaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXemTatCaActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            showNXB();
        } catch (SQLException ex) {
            Logger.getLogger(QuanLyNXB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnXemTatCaActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        StringBuilder sb = new StringBuilder();
        DataValidator.validateEmpty(txtMaNXB, sb, "Mã NXB không được trống");
        DataValidator.validateEmpty(txtTenNXB, sb, "Tên NXB không được trống");
        DataValidator.validateEmpty(txtDiaChi, sb, "Địa chỉ không được để trống");
        DataValidator.validateEmpty(txtSDT, sb, "SĐT không được trống");

        if (sb.length() > 0) {
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, sb.toString(), "Lỗi");
            return;
        }

        try {
            if (kiemTra()) {
                NhaXuatBan nxb = new NhaXuatBan();
                nxb.setMaNXB(txtMaNXB.getText());
                nxb.setTenNXB(txtTenNXB.getText());
                nxb.setDiaChi(txtDiaChi.getText());
                nxb.setsDT(txtSDT.getText());

                NhaXuatBanDAO nxbDao = new NhaXuatBanDAO();
                if (nxbDao.insert(nxb)) {
                    MessageDialogConnectDB.showMessageDialog(giaoDienChinh, "Thông báo", "Nhà xuất bản đã được thêm");
                    showNXB();
                } else {
                    MessageDialogConnectDB.showConfirmDialog(giaoDienChinh, "Nhà xuất bản chưa được thêm do lỗi", "Cảnh báo");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, e.getMessage(), "Lỗi");
        }

    }//GEN-LAST:event_btnThemActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        StringBuilder sb = new StringBuilder();
        DataValidator.validateEmpty(txtMaNXB, sb, "Mã NXB không được để trống");
        if (sb.length() > 0) {
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, sb.toString(), "Lỗi");
            return;
        }
        if (MessageDialogConnectDB.showConfirmDialog(giaoDienChinh, "Bạn có muốn xóa nhà xuất bản này không ?", "Hỏi") == JOptionPane.NO_OPTION) {
            return;
        }
        try {
            @SuppressWarnings("unused")
			NhaXuatBan kh = new NhaXuatBan();
            NhaXuatBanDAO dao = new NhaXuatBanDAO();
            if (dao.deleteNXB(txtMaNXB.getText())) {
                MessageDialogConnectDB.showMessageDialog(giaoDienChinh, "Thông báo", "Nhà xuất bản đã được xóa");
                showNXB();
            } else {
                MessageDialogConnectDB.showConfirmDialog(giaoDienChinh, "Nhà xuất bản không được xóa", "Cảnh báo");
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, e.getMessage(), "Lỗi");
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnXoaTrangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaTrangActionPerformed
        // TODO add your handling code here:
        txtMaNXB.setText("");
        txtTenNXB.setText("");
        txtDiaChi.setText("");
        txtSDT.setText("");
    }//GEN-LAST:event_btnXoaTrangActionPerformed

    private void btnCapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapNhatActionPerformed
        // TODO add your handling code here:
        StringBuilder sb = new StringBuilder();
        DataValidator.validateEmpty(txtMaNXB, sb, "Mã NXB không được trống");
        DataValidator.validateEmpty(txtTenNXB, sb, "Tên NXB không được trống");
        DataValidator.validateEmpty(txtDiaChi, sb, "Địa chỉ không được để trống");
        DataValidator.validateEmpty(txtSDT, sb, "SĐT không được trống");

        if (sb.length() > 0) {
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, sb.toString(), "Lỗi");
            return;
        }
        if (MessageDialogConnectDB.showConfirmDialog(giaoDienChinh, "Bạn có muốn cập nhật nhà xuất bản này không ?", "Hỏi") == JOptionPane.NO_OPTION) {
            return;
        }
        try {
            if (kiemTra()) {
                NhaXuatBan nxb = new NhaXuatBan();
                nxb.setMaNXB(txtMaNXB.getText());
                nxb.setTenNXB(txtTenNXB.getText());
                nxb.setDiaChi(txtDiaChi.getText());
                nxb.setsDT(txtSDT.getText());

                NhaXuatBanDAO nxbDao = new NhaXuatBanDAO();
                if (nxbDao.Update(nxb)) {
                    MessageDialogConnectDB.showMessageDialog(giaoDienChinh, "Thông báo", "Cập nhật thành công");
                    showNXB();
                } else {
                    MessageDialogConnectDB.showConfirmDialog(giaoDienChinh, "Nhà xuất bản không được cập nhật", "Cảnh báo");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, e.getMessage(), "Lỗi");
        }
    }//GEN-LAST:event_btnCapNhatActionPerformed

    private void tblNXBAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tblNXBAncestorAdded
        // TODO add your handling code here:
//        try {
//            int row = tblNXB.getSelectedRow();
//
//            if (row >= 0) {
//                String id = (String) tblNXB.getValueAt(row, 0);
//                NhaXuatBanDAO dao = new NhaXuatBanDAO();
//                NhaXuatBan nxb = dao.TimKiemNXBIsMaNXB(id);
//
//                if (nxb != null) {
//                    txtmaNXB.setText(nxb.getMaNXB());
//                    txtTenNXB.setText(nxb.getTenNXB());
//                    txtDiaChiNXB.setText(nxb.getDiaChi());
//                    txtSDT.setText(nxb.getsDT());
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, e.getMessage(), "Lỗi");
//        }
    }//GEN-LAST:event_tblNXBAncestorAdded

    private void tblNXBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNXBMouseClicked
        // TODO add your handling code here:
        try {
            int row = tblNXB.getSelectedRow();

            if (row >= 0) {
                String id = (String) tblNXB.getValueAt(row, 0);
                NhaXuatBanDAO dao = new NhaXuatBanDAO();
                NhaXuatBan nxb = dao.TimKiemNXBIsMaNXB(id);

                if (nxb != null) {
                    txtMaNXB.setText(nxb.getMaNXB());
                    txtTenNXB.setText(nxb.getTenNXB());
                    txtDiaChi.setText(nxb.getDiaChi());
                    txtSDT.setText(nxb.getsDT());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialogConnectDB.showErrorDialog(giaoDienChinh, e.getMessage(), "Lỗi");
        }
    }//GEN-LAST:event_tblNXBMouseClicked
    private boolean kiemTra() {

        if (regex.kiemTraRong(txtMaNXB)) {
            return false;
        }
        if (regex.RegexMaNXB(txtMaNXB)) {
            return false;
        }
        if (regex.kiemTraRong(txtTenNXB)) {
            return false;
        }
        if (regex.RegexTen(txtTenNXB)) {
            return false;
        }
        if (regex.kiemTraRong(txtDiaChi)) {
            return false;
        }
        if (regex.RegexDiaChi(txtDiaChi)) {
            return false;
        }
        if (regex.kiemTraRong(txtSDT)) {
            return false;
        }
        if (regex.RegexSDT(txtSDT)) {
            return false;
        }

        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnCapNhat;
    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnThem;
    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnXemTatCa;
    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnXoa;
    private com.mycompany.quanlybansach.ui.support.ButtonCustom btnXoaTrang;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblSDTNXB;
    private javax.swing.JLabel lbldiachiNXB;
    private javax.swing.JLabel lblmaNXB;
    private javax.swing.JLabel lbltenNXB;
    private com.mycompany.quanlybansach.ui.support.PanelRound pnlBTN;
    private javax.swing.JPanel pnlbg;
    private com.mycompany.quanlybansach.ui.support.PanelRound pnltableNXB;
    private com.mycompany.quanlybansach.ui.support.PanelRound pnlthongtinNCC;
    private javax.swing.JTable tblNXB;
    private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtDiaChi;
    private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtMaNXB;
    private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtSDT;
    private com.mycompany.quanlybansach.ui.support.TextFieldSuggestion txtTenNXB;
    // End of variables declaration//GEN-END:variables
}

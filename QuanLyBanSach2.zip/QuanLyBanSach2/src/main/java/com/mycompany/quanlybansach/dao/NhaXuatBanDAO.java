/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.dao;

/**
 *
 * @author quang
 */
import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.NhaXuatBan;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class NhaXuatBanDAO {

    private Connection con;

    public NhaXuatBanDAO() {
        con = ConnectDB.getInstance().getConnection();
    }

    // Them NXB
    public boolean insert(NhaXuatBan nxb) throws SQLException {
        String sql = "INSERT INTO [dbo].[NhaXuatBan]\r\n" + "           ([MaNXB]\r\n" + "           ,[TenNXB]\r\n"
                + "           ,[DiaChi]\r\n" + "           ,[SDT])\r\n" + "     VALUES\r\n" + "           (?,?,?,?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, nxb.getMaNXB());
        stmt.setString(2, nxb.getTenNXB());
        stmt.setString(3, nxb.getDiaChi());
        stmt.setString(4, nxb.getsDT());

        return stmt.executeUpdate() > 0;
    }

    // Xoa NXB
    public boolean deleteNXB(String maNXB) throws SQLException {
        String sql = "DELETE FROM [dbo].[NhaXuatBan]\r\n" + "      WHERE MaNXB = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maNXB);

        return stmt.executeLargeUpdate() > 0;
    }

    // Update NXB
    public boolean Update(NhaXuatBan nxb) throws SQLException {
        String sql = "UPDATE [dbo].[NhaXuatBan]\r\n" + "   SET [MaNXB] = ?\r\n" + "      ,[TenNXB] = ?\r\n"
                + "      ,[DiaChi] = ?\r\n" + "      ,[SDT] = ?\r\n" + " WHERE MaNXB = ?";

        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, nxb.getMaNXB());
        stmt.setString(2, nxb.getTenNXB());
        stmt.setString(3, nxb.getDiaChi());
        stmt.setString(4, nxb.getsDT());
        stmt.setString(5, nxb.getMaNXB());

        return stmt.executeUpdate() > 0;
    }

    //Tim kiem NXB theo ma NXB
    public NhaXuatBan TimKiemNXBIsMaNXB(String maNXB) throws SQLException {
        String sql = "SELECT [MaNXB]\r\n" + "      ,[TenNXB]\r\n" + "      ,[DiaChi]\r\n" + "      ,[SDT]\r\n"
                + "  FROM [dbo].[NhaXuatBan]\r\n" + "  WHERE MaNXB = ?";

        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maNXB);

        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            String tenNXB = rs.getString(2);
            String diaChi = rs.getString(3);
            String sDT = rs.getString(4);

            NhaXuatBan nxb = new NhaXuatBan(maNXB, tenNXB, diaChi, sDT);
            return nxb;
        }

        return null;
    }

    //Tim kiem NXB theo ten NXB
    public NhaXuatBan TimKiemNXBIsTenNXB(String tenNXB) throws SQLException {
        String sql = "SELECT [MaNXB]\r\n" + "      ,[TenNXB]\r\n" + "      ,[DiaChi]\r\n" + "      ,[SDT]\r\n"
                + "  FROM [dbo].[NhaXuatBan]\r\n" + "  WHERE TenNXB = ?";

        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, tenNXB);

        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            String maNXB = rs.getString("MaNXB");
            String diaChi = rs.getString("DiaChi");
            String sDT = rs.getString("SDT");

            NhaXuatBan nxb = new NhaXuatBan(maNXB, tenNXB, diaChi, sDT);
            return nxb;
        }

        return null;
    }

    //Danh sach NXB
    public List<NhaXuatBan> DanhSachNXB() throws SQLException {
        String sql = "SELECT * FROM [dbo].[NhaXuatBan]";

        List<NhaXuatBan> nhaXuatBans = new ArrayList<>();
        PreparedStatement stmt = con.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            String maNXB = rs.getString("MaNXB");
            String tenNXB = rs.getString("TenNXB");
            String diaChi = rs.getString("DiaChi");
            String sDT = rs.getString("SDT");

            NhaXuatBan nxb = new NhaXuatBan(maNXB, tenNXB, diaChi, sDT);
            nhaXuatBans.add(nxb);
        }

        return nhaXuatBans;
    }

    public List<String> DanhSachTenNXB() throws SQLException {
        String sql = "SELECT TenNXB FROM [dbo].[NhaXuatBan]";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        List<String> nxbList = new ArrayList<String>();
        while (rs.next()) {
            String nxb = rs.getString("TenNXB");
            nxbList.add(nxb);
        }
        return nxbList;
    }

    public String getMaNXB(String tenNXB) throws SQLException {
        String sql = "SELECT MaNXB FROM [dbo].[NhaXuatBan] WHERE TenNXB LIKE N'%' + ? + '%'";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1, tenNXB);
        ResultSet rs = pstmt.executeQuery();
        String maNXB = null;
        if (rs.next()) {
            maNXB = rs.getString("MaNXB");
        }
        return maNXB;
    }
}

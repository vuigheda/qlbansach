/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

import java.sql.Timestamp;

/**
 *
 * @author quang
 */

public class HoaDon {
	private int maHD;
	private KhachHang maKH;
	private NhanVien maNV;
	private Timestamp ngayLapHoaDon;
	private double tienKhachTra;
	private double tienKhacDu;
	private double tongTien;

	public HoaDon() {
		super();
	}

	public HoaDon(int maHD, KhachHang maKH, NhanVien maNV, Timestamp ngayLapHoaDon, double tienKhachTra,
			double tienKhacDu, double tongTien) {
		super();
		this.maHD = maHD;
		this.maKH = maKH;
		this.maNV = maNV;
		this.ngayLapHoaDon = ngayLapHoaDon;
		this.tienKhachTra = tienKhachTra;
		this.tienKhacDu = tienKhacDu;
		this.tongTien = tongTien;
	}

	public int getMaHD() {
		return maHD;
	}

	public void setMaHD(int maHD) {
		this.maHD = maHD;
	}

	public KhachHang getMaKH() {
		return maKH;
	}

	public void setMaKH(KhachHang maKH) {
		this.maKH = maKH;
	}

	public NhanVien getMaNV() {
		return maNV;
	}

	public void setMaNV(NhanVien maNV) {
		this.maNV = maNV;
	}

	public Timestamp getNgayLapHoaDon() {
		return ngayLapHoaDon;
	}

	public void setNgayLapHoaDon(Timestamp ngayLapHoaDon) {
		this.ngayLapHoaDon = ngayLapHoaDon;
	}

	public double getTienKhachTra() {
		return tienKhachTra;
	}

	public void setTienKhachTra(double tienKhachTra) {
		this.tienKhachTra = tienKhachTra;
	}

	public double getTienKhacDu() {
		return tienKhacDu;
	}

	public void setTienKhacDu(double tienKhacDu) {
		this.tienKhacDu = tienKhacDu;
	}

	public double getTongTien() {
		return tongTien;
	}

	public void setTongTien(double tongTien) {
		this.tongTien = tongTien;
	}

	@Override
	public String toString() {
		return "HoaDon [maHD=" + maHD + ", maKH=" + maKH + ", maNV=" + maNV + ", ngayLapHoaDon=" + ngayLapHoaDon
				+ ", tienKhachTra=" + tienKhachTra + ", tienKhacDu=" + tienKhacDu + ", tongTien=" + tongTien + "]";
	}

}

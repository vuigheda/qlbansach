package com.mycompany.quanlybansach.dao;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.HoaDon;
import com.mycompany.quanlybansach.entity.KhachHang;
import com.mycompany.quanlybansach.entity.NhanVien;
import com.mycompany.quanlybansach.entity.SanPham;

import java.sql.*;
import java.util.ArrayList;

import java.util.List;

public class ThongKeDAO {

    private static Connection conn;

    public ThongKeDAO() {
        conn = ConnectDB.getInstance().getConnection();
    }

    public static void main(String[] args) {
        ThongKeDAO dao = new ThongKeDAO();
        try {
//            KhachHang kh = dao.showThongKeKhachHangBest("2023-04-11", "2023-04-16");
//            System.out.println(kh);
//            System.out.println(dao.showBestSellerProduct());
//            System.out.println(dao.showSlowestSellingProduct());
//            System.out.println(showSoLuongDauSach());
//            System.out.println(showSoLuongLoaiDungCuHocTap());
//            System.out.println(dao.showThongKeKhachHangBest("2023-04-11", "2023-04-16"));
//            System.out.println(dao.showAllCustomer("2023-04-11", "2023-04-16"));
        	System.out.println(dao.tongSoLuongBan("SP002"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<HoaDon> showThongKeDoanhThu(String startDay, String endDay) throws SQLException {
        String sql = "SELECT * FROM[dbo].[HoaDon] WHERE CAST([NgayLapHoaDon] AS DATE) BETWEEN  ? AND ?";
        List<HoaDon> dsHoaDon = new ArrayList<>();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setDate(1, Date.valueOf(startDay));
        stmt.setDate(2, Date.valueOf(endDay));
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            HoaDon hd = new HoaDon();
            KhachHang kh = new KhachHang();
            NhanVien nv = new NhanVien();

            hd.setMaHD(rs.getInt("MaHD"));
            kh.setMaKH(rs.getString("MaKH"));
            nv.setMaNV(rs.getString("MaNV"));

            hd.setMaKH(kh);
            hd.setMaNV(nv);
            hd.setNgayLapHoaDon(rs.getTimestamp("NgayLapHoaDon"));
            hd.setTongTien(rs.getDouble("TongTien"));

            dsHoaDon.add(hd);
        }

        return dsHoaDon;
    }


    public List<KhachHang> showAllCustomer(String startDay, String endDay) throws SQLException {
        String sql = "SELECT  dbo.HoaDon.MaKH AS MaKH, dbo.HoaDon.NgayLapHoaDon, dbo.KhachHang.TenKH, \n" +
                "dbo.KhachHang.DiaChi, dbo.KhachHang.GioiTinh, dbo.KhachHang.SDT\n" +
                "FROM dbo.HoaDon INNER JOIN dbo.KhachHang ON dbo.HoaDon.MaKH = dbo.KhachHang.MaKH \n" +
                "where CAST([NgayLapHoaDon] AS DATE) BETWEEN  ? AND ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setDate(1, Date.valueOf(startDay));
        stmt.setDate(2, Date.valueOf(endDay));
        ResultSet rs = stmt.executeQuery();
        List<KhachHang> lst = new ArrayList<>();
        while (rs.next()) {
            KhachHang kh = new KhachHang();
            kh.setMaKH(rs.getString("MaKH"));
            kh.setTenKH(rs.getString("TenKH"));
            kh.setDiaChi(rs.getString("DiaChi"));
            kh.setGioiTinh(rs.getInt("GioiTinh"));
            kh.setsDT(rs.getString("SDT"));
            if (!lst.contains(kh)) {
                lst.add(kh);
            }

        }

        return lst;
    }

    public KhachHang showThongKeKhachHangBest(String startDay, String endDay) throws SQLException {
        String sql = "SELECT TOP 1 HoaDon.MaKH, count(HoaDon.MaKH)\n" +
                "FROM HoaDon where CAST([NgayLapHoaDon] AS DATE) BETWEEN  ? AND ? \n" +
                "GROUP BY HoaDon.MaKH order by  count(HoaDon.MaKH) desc";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setDate(1, Date.valueOf(startDay));
        stmt.setDate(2, Date.valueOf(endDay));
        ResultSet rs = stmt.executeQuery();
        KhachHang kh = new KhachHang();
        rs.next();
        String maKH = rs.getString(1);
//        while (rs.next()) {
//
////            kh.setMaKH(rs.getString("MaKH"));
////            kh.setTenKH(rs.getString("TenKH"));
////            kh.setDiaChi(rs.getString("DiaChi"));
////            kh.setGioiTinh(rs.getInt("GioiTinh"));
////            kh.setsDT(rs.getString("SDT"));
//            System.out.println(rs.);
//        }

        if (!maKH.equals("")) {
            String sql2 = "select * from KhachHang where MaKH = ?";
            PreparedStatement stmt2 = conn.prepareStatement(sql2);
            stmt2.setString(1, maKH);
            ResultSet rs2 = stmt2.executeQuery();
            while (rs2.next()) {
                kh.setMaKH(rs2.getString("MaKH"));
                kh.setTenKH(rs2.getString("TenKH"));
                kh.setDiaChi(rs2.getString("DiaChi"));
                kh.setGioiTinh(rs2.getInt("GioiTinh"));
                kh.setsDT(rs2.getString("SDT"));
            }
            return kh;
        }

        return null;
    }

    public KhachHang showThongKeKhachHangBad(String startDay, String endDay) throws SQLException {
        String sql = "SELECT *\n" +
                "FROM ( KhachHang INNER JOIN HoaDon\n" +
                "ON KhachHang.MaKH=HoaDon.MaKH )\n" +
                "WHERE TongTien = (SELECT MIN(TongTien) FROM HoaDon) AND CAST([NgayLapHoaDon] AS DATE) BETWEEN  ? AND ? ";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setDate(1, Date.valueOf(startDay));
        stmt.setDate(2, Date.valueOf(endDay));
        ResultSet rs = stmt.executeQuery();
        KhachHang kh = new KhachHang();
        while (rs.next()) {

            kh.setMaKH(rs.getString("MaKH"));
            kh.setTenKH(rs.getString("TenKH"));
            kh.setDiaChi(rs.getString("DiaChi"));
            kh.setGioiTinh(rs.getInt("GioiTinh"));
            kh.setsDT(rs.getString("SDT"));
        }

        return kh;
    }

    public SanPham showBestSellerProduct() throws SQLException {
        String sql = "SELECT MaSP, SUM(SoLuong) as TongSoLuong\n" +
                "FROM ChiTietHoaDon\n" +
                "GROUP BY MaSP\n" +
                "ORDER BY TongSoLuong DESC\n" +
                "OFFSET 0 ROWS\n" +
                "FETCH NEXT 1 ROWS ONLY;\n" +
                "\n";
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        SanPham sp = new SanPham();
        String maSP = null;
        @SuppressWarnings("unused")
		Double tongSoLuong = null;
        while (rs.next()) {
//            sp.setMaSP(rs.getString("MaSp"));
//            sp.setLoaiSP(rs.getString("LoaiSP"));
//            sp.setTenSP(rs.getString("TenSP"));
//            sp.setSoLuong(rs.getInt("SoLuong"));
//            sp.setDonGia(rs.getDouble("DonGia"));
            maSP = rs.getString("MaSp");
            tongSoLuong = rs.getDouble("TongSoLuong");

        }
        System.out.println(maSP);

        if (maSP != null) {
            String querriesForSanPham = "select * from SanPham where MaSP = ?";
            PreparedStatement stmt2 = conn.prepareStatement(querriesForSanPham);
            stmt2.setString(1, maSP);
            ResultSet rs2 = stmt2.executeQuery();
//            rs2.next();
//            System.out.println(rs2.getString(3));
            while (rs2.next()) {
                sp.setMaSP(rs2.getString("MaSp"));
                sp.setLoaiSP(rs2.getString("LoaiSP"));
                sp.setTenSP(rs2.getString("TenSP"));
                sp.setSoLuong(rs2.getInt("SoLuong"));
                sp.setDonGia(rs2.getDouble("DonGia"));
            }
            return sp;
        }
        return null;
    }
    
    public Double tongSoLuongBan(String maSp) throws SQLException {
    	 String sql = "SELECT MaSP, SUM(SoLuong) as TongSoLuong\n" +
                 "FROM ChiTietHoaDon\n" +
                 "GROUP BY MaSP\n" +
                 "ORDER BY TongSoLuong DESC\n" +
                 "OFFSET 0 ROWS\n" +
                 "FETCH NEXT 1 ROWS ONLY;\n" +
                 "\n";
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery();
         rs.next();
//         System.out.print(rs.getDouble(2));
         
         return rs.getDouble(2);
    }
    
    public Double tongSoLuongBanChamNhat(String maSp) throws SQLException {
   	 String sql = "SELECT Top 1 MaSP, SUM(SoLuong) as TongSoLuong\n" +
             "FROM ChiTietHoaDon\n" +
             "GROUP BY MaSP\n" +
             "ORDER BY TongSoLuong ";
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        rs.next();
//        System.out.print(rs.getDouble(2));
        
        return rs.getDouble(2);
   }

    public SanPham showSlowestSellingProduct() throws SQLException {
        String sql = "SELECT Top 1 MaSP, SUM(SoLuong) as TongSoLuong\n" +
                "FROM ChiTietHoaDon\n" +
                "GROUP BY MaSP\n" +
                "ORDER BY TongSoLuong ";
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        rs.next();
        String maSP = rs.getString(1);

        SanPham sp = new SanPham();
//        while (rs.next()) {
//            sp.setMaSP(rs.getString("MaSp"));
//            sp.setLoaiSP(rs.getString("LoaiSP"));
//            sp.setTenSP(rs.getString("TenSP"));
//            sp.setSoLuong(rs.getInt("SoLuong"));
//            sp.setDonGia(rs.getDouble("DonGia"));
//        }

        if (maSP != "") {
            String sql2 = "select  * from SanPham where MaSP = ?";
            PreparedStatement stmt2 = conn.prepareStatement(sql2);
            stmt2.setString(1, maSP);
            ResultSet rs2 = stmt2.executeQuery();
            while (rs2.next()) {
                sp.setMaSP(rs2.getString("MaSp"));
                sp.setLoaiSP(rs2.getString("LoaiSP"));
                sp.setTenSP(rs2.getString("TenSP"));
                sp.setSoLuong(rs2.getInt("SoLuong"));
                sp.setDonGia(rs2.getDouble("DonGia"));
            }

            return sp;
        }

        return null;
    }

    public int showSoLuongDauSach() throws SQLException {
        String sql = "Select * from SanPham where LoaiSP = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, "Sách");
        ResultSet rs = stmt.executeQuery();

        int rowConut = 0;
        while (rs.next()) {
            rowConut += 1;
        }
        ;
        return rowConut;
    }

    public int showSoLuongLoaiDungCuHocTap() throws SQLException {
        String sql = "Select * from SanPham where LoaiSP = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, "Dụng cụ học tập");
        ResultSet rs = stmt.executeQuery();

        int rowConut = 0;
        while (rs.next()) {
            rowConut += 1;
        }
        ;
        return rowConut;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quanlybansach.entity;

/**
 *
 * @author quang
 */


public class SanPham {
	private String maSP;
	private String loaiSP;
	private String tenSP;
	private int soLuong;
	private double donGia;

	public SanPham() {
		super();
	}

	public SanPham(String maSP, String loaiSP, String tenSP, int soLuong, double donGia) {
		super();
		this.maSP = maSP;
		this.loaiSP = loaiSP;
		this.tenSP = tenSP;
		this.soLuong = soLuong;
		this.donGia = donGia;
	}

	public String getMaSP() {
		return maSP;
	}

	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}

	public String getLoaiSP() {
		return loaiSP;
	}

	public void setLoaiSP(String loaiSP) {
		this.loaiSP = loaiSP;
	}

	public String getTenSP() {
		return tenSP;
	}

	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}

	public double getDonGia() {
		return donGia;
	}

	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}

	@Override
	public String toString() {
		return "SanPham [maSP=" + maSP + ", loaiSP=" + loaiSP + ", tenSP=" + tenSP + ", soLuong=" + soLuong
				+ ", donGia=" + donGia + "]";
	}

}


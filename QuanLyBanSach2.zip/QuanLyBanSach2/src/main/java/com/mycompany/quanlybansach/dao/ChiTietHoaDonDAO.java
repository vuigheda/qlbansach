package com.mycompany.quanlybansach.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.quanlybansach.connectDB.ConnectDB;
import com.mycompany.quanlybansach.entity.ChiTietHoaDon;
import com.mycompany.quanlybansach.entity.HoaDon;
import com.mycompany.quanlybansach.entity.SanPham;

public class ChiTietHoaDonDAO {
	private Connection con;

    public ChiTietHoaDonDAO() {
        con = ConnectDB.getInstance().getConnection();
    }
    
    public boolean ThemCTHoaDon(ChiTietHoaDon cthd) {

        try {
            String sql = "INSERT INTO [dbo].[ChiTietHoaDon]\r\n"
            		+ "           ([MaCTHD]\r\n"
            		+ "           ,[MaHD]\r\n"
            		+ "           ,[MaSP]\r\n"
            		+ "           ,[SoLuong]\r\n"
            		+ "           ,[DonGia])\r\n"
            		+ "     VALUES\r\n"
            		+ "           (?,?,?,?,?)";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cthd.getMaCTHD());
            stmt.setInt(2, cthd.getMaHD().getMaHD());
            stmt.setString(3, cthd.getMaSP().getMaSP());
            stmt.setInt(4, cthd.getSoLuong());
            stmt.setDouble(5, cthd.getDonGia());

            int n = stmt.executeUpdate();

            return n > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    
    public boolean update(ChiTietHoaDon cthd) throws SQLException {

        String sql = "UPDATE [dbo].[ChiTietHoaDon]\r\n"
        		+ "   SET [MaCTHD] = ?\r\n"
        		+ "      ,[MaHD] = ?\r\n"
        		+ "      ,[MaSP] = ?\r\n"
        		+ "      ,[SoLuong] = ?\r\n"
        		+ "      ,[DonGia] = ?\r\n"
        		+ " WHERE MaCTHD = ?";

        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, cthd.getMaCTHD());
        stmt.setInt(2, cthd.getMaHD().getMaHD());
        stmt.setString(3, cthd.getMaSP().getMaSP());
        stmt.setInt(4, cthd.getSoLuong());
        stmt.setDouble(5, cthd.getDonGia());
        stmt.setString(6, cthd.getMaCTHD());

        return stmt.executeUpdate() > 0;
    }
    
    public boolean deleteMaCTHD(String maCTHD) throws SQLException {

        String sql = "\r\n"
        		+ "DELETE FROM [dbo].[ChiTietHoaDon]\r\n"
        		+ "      WHERE MaCTHD = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maCTHD);

        return stmt.executeLargeUpdate() > 0;

    }
    
    public List<ChiTietHoaDon> LoadCTHoaDon() throws SQLException {
        String sql = "SELECT [MaCTHD]\r\n"
        		+ "      ,[MaHD]\r\n"
        		+ "      ,[MaSP]\r\n"
        		+ "      ,[SoLuong]\r\n"
        		+ "      ,[DonGia]\r\n"
        		+ "  FROM [dbo].[ChiTietHoaDon]";
        List<ChiTietHoaDon> dsCTHD = new ArrayList<>();
        PreparedStatement stmt = con.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
        	ChiTietHoaDon chiTietHoaDon = new ChiTietHoaDon();
        	HoaDon hd = new HoaDon();
        	SanPham sp = new SanPham();
        	
        	chiTietHoaDon.setMaCTHD(rs.getString("MaCTHD"));
        	hd.setMaHD(rs.getInt("MaHD"));
        	sp.setMaSP(rs.getString("MaSP"));
        	chiTietHoaDon.setMaHD(hd);
        	chiTietHoaDon.setMaSP(sp);
        	chiTietHoaDon.setSoLuong(rs.getInt("SoLuong"));
        	chiTietHoaDon.setDonGia(rs.getDouble("DonGia"));
        	
            dsCTHD.add(chiTietHoaDon);
        }

        return dsCTHD;
    }
   
    
    public ChiTietHoaDon getCTHoaDonTheoMaCTHD(String maCTHD) throws SQLException {
        String sql = "SELECT * FROM [dbo].[ChiTietHoaDon] WHERE MaCTHD = ?";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, maCTHD);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
        	ChiTietHoaDon chiTietHoaDon = new ChiTietHoaDon();
        	HoaDon hd = new HoaDon();
        	SanPham sp = new SanPham();
        	
        	chiTietHoaDon.setMaCTHD(rs.getString("MaCTHD"));
        	hd.setMaHD(rs.getInt("MaHD"));
        	sp.setMaSP(rs.getString("MaSP"));
        	chiTietHoaDon.setMaHD(hd);
        	chiTietHoaDon.setMaSP(sp);
        	chiTietHoaDon.setSoLuong(rs.getInt("SoLuong"));
        	chiTietHoaDon.setDonGia(rs.getDouble("DonGia")); 
            
            return chiTietHoaDon;
        }

        return null;
    }
    
    public String generateMaCTHD() throws SQLException {
		String MaCTHD = null;
		String prefix = "CTHD";
		String sql = "SELECT MAX(MaCTHD) FROM ChiTietHoaDon";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);

		rs.next();
		String maxMaCTHD = rs.getString(1);
		int index = 1;

		if (maxMaCTHD != null) {
			String numericPart = maxMaCTHD.substring(prefix.length()).trim();
			index = Integer.parseInt(numericPart) + 1;
		}

		MaCTHD = prefix + String.format("%03d", index);

		return MaCTHD;
	}
    
    public List<CTHDDTO> DanhSachCTHoaDonIsMaHD(int maHD) throws SQLException {
        String sql = "SELECT    dbo.ChiTietHoaDon.MaSP, dbo.SanPham.TenSP, dbo.ChiTietHoaDon.SoLuong, dbo.SanPham.DonGia, dbo.ChiTietHoaDon.DonGia AS ThanhTien\r\n"
        		+ "FROM         dbo.ChiTietHoaDon INNER JOIN\r\n"
        		+ "                      dbo.SanPham ON dbo.ChiTietHoaDon.MaSP = dbo.SanPham.MaSP\r\n"
        		+ "WHERE MaHD = ?";
        List<CTHDDTO> dsCTHD = new ArrayList<>();
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, maHD);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
        	CTHDDTO chiTietHoaDon = new CTHDDTO();      
        	
        	chiTietHoaDon.setMaSP(rs.getString("MaSP"));
        	chiTietHoaDon.setTenSP(rs.getString("TenSP"));
        	chiTietHoaDon.setSoLuong(rs.getInt("SoLuong"));
        	chiTietHoaDon.setDonGia(rs.getDouble("DonGia"));
        	chiTietHoaDon.setThanhTien(rs.getDouble("ThanhTien"));       	
            dsCTHD.add(chiTietHoaDon);
        }

        return dsCTHD;
    }
    
    public class CTHDDTO{
    	private String maSP;
    	private String tenSP;
    	private int soLuong;
    	private double donGia;
    	private double thanhTien;
    	
		public CTHDDTO() {
			super();
			
		}
		public CTHDDTO(String maSP, String tenSP, int soLuong, double donGia, double thanhTien) {
			super();
			this.maSP = maSP;
			this.tenSP = tenSP;
			this.soLuong = soLuong;
			this.donGia = donGia;
			this.thanhTien = thanhTien;
		}
		public String getMaSP() {
			return maSP;
		}
		public void setMaSP(String maSP) {
			this.maSP = maSP;
		}
		public String getTenSP() {
			return tenSP;
		}
		public void setTenSP(String tenSP) {
			this.tenSP = tenSP;
		}
		public int getSoLuong() {
			return soLuong;
		}
		public void setSoLuong(int soLuong) {
			this.soLuong = soLuong;
		}
		public double getDonGia() {
			return donGia;
		}
		public void setDonGia(double donGia) {
			this.donGia = donGia;
		}
		public double getThanhTien() {
			return thanhTien;
		}
		public void setThanhTien(double thanhTien) {
			this.thanhTien = thanhTien;
		}
    }
}
